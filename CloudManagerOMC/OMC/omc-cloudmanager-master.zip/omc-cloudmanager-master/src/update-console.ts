const opn = require("opn");

import { container, app } from "./app";
import { UpdateHelper } from "./helpers/update-init";
import { Pulse } from "./services/pulse";
import { TYPES } from "./types";
import { ProgramService } from "./services/programs";
import { Config } from "./services/config";

const updateHelper = new UpdateHelper();

const pulse: Pulse = container.get(TYPES.Pulse);
const programService: ProgramService = container.get(TYPES.ProgramService);
const config: Config = container.get(TYPES.Config);

pulse.addInitHook(() => {
  updateHelper.initPulse(pulse, container.get(TYPES.Ims));
});
pulse.reset();
programService.addInitHook(() => {
  updateHelper.initPrograms(programService);
});
programService.reset();
updateHelper.initConfig(config);

app.listen(app.get("port"), () => {
  console.log(
    "  OMC Cloud Manager listening on port %d",
    app.get("port")
  );
  opn(`http://localhost:${app.get("port")}`);
  console.log("  Press CTRL-C to stop\n");
});
