import { container, app } from "./app";
import { UpdateHelper } from "./helpers/update-init";
import { TYPES } from "./types";
import { ProgramService } from "./services/programs";
import { Pulse } from "./services/pulse";
import { Config } from "./services/config";

const updateHelper = new UpdateHelper();

const pulse: Pulse = container.get(TYPES.Pulse);
const programService: ProgramService = container.get(TYPES.ProgramService);
const config: Config = container.get(TYPES.Config);

pulse.addInitHook(() => {
  updateHelper.initPulse(container.get(TYPES.Pulse), container.get(TYPES.Ims));
});
pulse.reset();
programService.addInitHook(() => {
  updateHelper.initPrograms(programService);
});
programService.reset();
updateHelper.initConfig(config);

app.listen(app.get("port"), () => {
  console.log(
    "  OMC Cloud Manager listening on port %d",
    app.get("port")
  );
  console.log("  Press CTRL-C to stop\n");
});
