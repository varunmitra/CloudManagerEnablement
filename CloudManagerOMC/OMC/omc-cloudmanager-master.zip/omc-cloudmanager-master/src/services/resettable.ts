import { BaseService } from "./base";
import * as _ from "lodash";

export interface Resettable {
    reset(): void;

    addInitHook(hook: InitHook): void;
}

export type InitHook = () => void;

export abstract class BaseResettable extends BaseService implements Resettable {

    private initHooks: InitHook[];

    public constructor() {
        super();
        this.initHooks = [];
        this.reset();
    }

    public abstract reset(): void;

    protected invokeInitHooks(): void {
        _.each(this.initHooks, hook => {
            hook();
        });
    }

    public addInitHook(hook: InitHook) {
        this.initHooks.push(hook);
    }
}