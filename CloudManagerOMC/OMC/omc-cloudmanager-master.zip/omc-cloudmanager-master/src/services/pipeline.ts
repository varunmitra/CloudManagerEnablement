import { injectable, inject } from "inversify";
import { ProgramService } from "./programs";
import { TYPES } from "../types";
import * as _ from "lodash";
import moment from "moment";
import { Pulse, Action } from "./pulse";
import { Ims } from "./ims";
import { Config, StepType, CiCdPipelineType } from "./config";
import { stringify } from "querystring";
import { pipelineExecution_status, pipeline_type } from "../models";
import { isCloud } from "../helpers/program-helper";
const leftPad = require("left-pad");

export interface PipelineService {
    findPipeline(programId: string, pipelineId: string): any;
    startCiCdExecution(programId: string, pipelineId: string): string;
    startCodeGeneratorExecution(programId: string, body: any): string;
    overrideCodeQuality(programId: string, executionId: string): void;
    overrideSecurityTest(programId: string, executionId: string): void;
    overridePerformanceTest(programId: string, executionId: string): void;
    approve(programId: string, executionId: string): void;
    schedule(programId: string, executionId: string): void;
}

@injectable()
export class PipelineServiceImpl implements PipelineService {

    @inject(TYPES.ProgramService) private programService: ProgramService;
    @inject(TYPES.Pulse) private pulse: Pulse;
    @inject(TYPES.Ims) private imsService: Ims;
    @inject(TYPES.Config) private config: Config;

    public findPipeline(programId: string, pipelineId: string): any {
        const program = this.programService.getRawProgram(programId);

        let pipeline: any;
        if (pipelineId === this.config.getMainPipelineName()) {
            pipeline = program.pipeline;
            pipeline.type = CiCdPipelineType.production;
        } else if (pipelineId === this.config.getValidatePipelineName()) {
            pipeline = program.validationPipeline;
            pipeline.type = CiCdPipelineType.production;
        } else {
            pipeline = _.find(program.nonProductionPipelines, p => p.name === pipelineId);
        }
        return pipeline;
    }

    public startCiCdExecution(programId: string, pipelineId: string) {
        const program = this.programService.getRawProgram(programId);
        const pipeline = this.findPipeline(programId, pipelineId);

        const maxExecution = _.maxBy(_.map(program.executions), (execution: any) => {
            return parseInt(execution.id, 10);
        });
        const newExecutionId = maxExecution ? parseInt(maxExecution.id, 10) + 1 : 1;
        let execution: any;
        if (program.branchExecutions && program.branchExecutions[pipeline.branch]) {
            execution = _.cloneDeep(program.branchExecutions[pipeline.branch]);
        } else {
            const sourceExecutionId = program.branchExecutionMapping[pipeline.branch];
            execution = _.cloneDeep(program.executions[sourceExecutionId]);
        }

        execution.status = "RUNNING";
        execution.pipelineId = pipelineId;
        execution.id = newExecutionId.toString();
        execution.createdAt = moment().format();
        execution.version = moment().format("YYYY.MDD.kmmss") + "." + leftPad(execution.id, 10, "0");
        delete execution.finishedAt;
        execution.overriddenSteps = [];
        execution.options = {};
        if (pipeline.goliveapproval) {
            execution.options.approval = true;
        }
        if (pipeline.scheduled) {
            execution.options.scheduled = true;
        }
        if (!isCloud(program) && pipeline.cseoversight) {
            execution.options.managed = true;
        }
        this.update(execution);
        execution.runningStep = StepType.validate;

        if (!program.executions) {
            program.executions = {};
        }
        program.executions[execution.id] = execution;
        if (!program.activeExecutionId) {
            program.activeExecutionId = {};
        }
        program.activeExecutionId[pipelineId] = execution.id;

        if (pipeline.type === CiCdPipelineType.production) {
            this.pulse.addEventStart("Pipeline Started", `Pipeline for ${program.title} has started.`, [
                new Action({
                    "url" : `/pipelineexecution.html/organization/${this.imsService.fullOrgId}/program/${program.id}/pipeline/main/execution/${newExecutionId}`
                })
            ]);
        }

        setTimeout(() => {
            this.finishValidate(programId, execution.id);
        }, this.config.getDuration(StepType.validate) * 1000);

        return execution.id;

    }

    public startCodeGeneratorExecution(programId: string, body: any) {
        body.packageName = body.package;
        const program = this.programService.getRawProgram(programId);

        const maxExecution = _.maxBy(_.map(program.executions), (execution: any) => {
            return parseInt(execution.id, 10);
        });
        const newExecutionId = maxExecution ? parseInt(maxExecution.id, 10) + 1 : 1;
        const execution: any = {
            status: pipelineExecution_status.RUNNING,
            id: newExecutionId.toString(),
            createdAt: moment().format(),
            pipelineType: pipeline_type.CODE_GENERATOR,
            input: body
        };

        this.update(execution);

        if (!program.executions) {
            program.executions = {};
        }
        program.executions[execution.id] = execution;

        setTimeout(() => {
            program.branches.push(body.branch);
            execution.finishedAt = moment().format();
            execution.status = pipelineExecution_status.FINISHED;
            this.pulse.addEventEnd("Project Creation Completed", `Project for ${program.title} in branch ${body.branch} has completed successfully.`,
                [ new Action({
                    "url" : `/pipelinesetup.html/organization/${this.imsService.fullOrgId}/program/{program.id}`
                    }) ], "multipleCheck", "GREEN");
        }, this.config.getDuration(StepType.codeGeneration) * 1000);

        return execution.id;
    }

    public overrideCodeQuality(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        execution.overriddenSteps.push(StepType.codeQuality);
        delete execution.waitingStep;
        this.afterCodeQuality(program, execution);
    }

    afterCodeQuality(program: any, execution: any) {
        if (execution.pipelineId === this.config.getMainPipelineName() || execution.pipelineId == this.config.getValidatePipelineName()) {
            this.startStageDeploy(program.id, execution);
        } else {
            const pipeline = _.find(program.nonProductionPipelines, p => p.name == execution.pipelineId);
            if (pipeline.type === CiCdPipelineType.nonProductionDeploy) {
                this.startDevDeploy(program.id, execution);
            } else {
                this.finish("FINISHED", "code quality", program, execution);
            }
        }
    }

    public overrideSecurityTest(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        execution.overriddenSteps.push(StepType.securityTest);
        delete execution.waitingStep;
        this.startPerformanceTest(programId, execution);
    }

    public overridePerformanceTest(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        execution.overriddenSteps.push(StepType.reportPerformanceTest);
        delete execution.waitingStep;
        this.startProdPhase(programId, execution);
    }

    private finishValidate(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        execution.runningStep = StepType.build;

        setTimeout(() => {
            this.finishBuild(programId, execution.id);
        }, this.config.getDuration(StepType.build) * 1000);
    }

    private finishBuild(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        execution.runningStep = StepType.codeQuality;

        setTimeout(() => {
            this.finishCodeQuality(programId, execution.id);
        }, this.config.getDuration(StepType.codeQuality) * 1000);
    }

    private finishCodeQuality(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        if (execution.failureStep == StepType.codeQuality) {
            this.finish("FAILED", "code quality", program, execution);
        } else if (execution.stepsRequiringOverride && execution.stepsRequiringOverride.indexOf(StepType.codeQuality) >= 0) {
            execution.waitingStep = StepType.codeQuality;
        } else {
            this.afterCodeQuality(program, execution);
        }
    }

    private startDevDeploy(programId: string, execution: any) {
        execution.runningStep = StepType.devDeploy;

        setTimeout(() => {
            this.finishDevDeploy(programId, execution.id);
        }, this.config.getDuration(StepType.devDeploy) * 1000);
    }

    private finishDevDeploy(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];

        this.finish("FINISHED", "dev deployment", program, execution);
    }

    private startStageDeploy(programId: string, execution: any) {
        execution.runningStep = StepType.stageDeploy;

        setTimeout(() => {
            this.finishStageDeploy(programId, execution.id);
        }, this.config.getDuration(StepType.stageDeploy) * 1000);
    }

    private finishStageDeploy(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);

        // if (isCloud(program)) {
        //    this.startProdPhase(programId, execution);
        // } else {
            this.startSecurityTest(programId, execution);
        // }
    }

    private startSecurityTest(programId: string, execution: any) {
        execution.runningStep = StepType.securityTest;

        setTimeout(() => {
            this.finishSecurityTest(programId, execution.id);
        }, this.config.getDuration(StepType.securityTest) * 1000);
    }

    private finishSecurityTest(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        if (execution.failureStep == StepType.securityTest) {
            this.finish("FAILED", "security test", program, execution);
        } else if (execution.stepsRequiringOverride && execution.stepsRequiringOverride.indexOf(StepType.securityTest) >= 0) {
            execution.waitingStep = StepType.securityTest;
        } else {
            this.startPerformanceTest(programId, execution);
        }
    }

    private startPerformanceTest(programId: string, execution: any) {
        execution.runningStep = StepType.reportPerformanceTest;

        setTimeout(() => {
            this.finishPerformanceTest(programId, execution.id);
        }, this.config.getDuration(StepType.reportPerformanceTest) * 1000);
    }

    private finishPerformanceTest(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        if (execution.failureStep == StepType.reportPerformanceTest) {
            this.finish("FAILED", "performance test", program, execution);
        } else if (execution.stepsRequiringOverride && execution.stepsRequiringOverride.indexOf(StepType.reportPerformanceTest) >= 0) {
            execution.waitingStep = StepType.reportPerformanceTest;
        } else {
            this.startProdPhase(programId, execution);
        }
    }

    public approve(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        execution.approved = true;
        delete execution.waitingStep;
        this.startProdPhase(programId, execution);
    }

    public schedule(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        this.update(execution);
        execution.scheduled = true;
        delete execution.waitingStep;
        this.startProdPhase(programId, execution);
    }

    private startProdPhase(programId: string, execution: any) {
        const program = this.programService.getRawProgram(programId);
        if (execution.options.approval && !execution.approved) {
            execution.runningStep = StepType.approval;
            execution.waitingStep = StepType.approval;
            this.pulse.addActionRequired("Staging Deployment Requires Approval", `Staging Deployment for ${program.title} complete and requires approval.`,
                "browse", "RED", [ new Action({
                    "url" : `/pipelineexecution.html/organization/${this.imsService.fullOrgId}/program/${program.id}/pipeline/main/execution/${execution.id}`
                }) ]);
        } else if (execution.options.scheduled && !execution.scheduled) {
            execution.runningStep = StepType.schedule;
            execution.waitingStep = StepType.schedule;
            this.pulse.addActionRequired("Schedule Production Deployment", `Production Deployment for ${program.title} needs to be scheduled.`,
                "calendarCheckColor", "NO_COLOR", [ new Action({
                    "url" : `/pipelineexecution.html/organization/${this.imsService.fullOrgId}/program/${program.id}/pipeline/main/execution/${execution.id}`
                }) ]);
        } else if (execution.options.managed && !execution.managed) {
            execution.runningStep = StepType.managed;
            execution.waitingStep = StepType.managed;
            setTimeout(() => {
                execution.managed = true;
                delete execution.waitingStep;
                this.startProdPhase(programId, execution);
            }, this.config.getDuration(StepType.managed) * 1000);
        } else {
            this.startProdDeploy(programId, execution);
        }
    }

    private startProdDeploy(programId: string, execution: any) {
        execution.runningStep = StepType.prodDeploy;

        setTimeout(() => {
            this.finishProdDeploy(programId, execution.id);
        }, this.config.getDuration(StepType.prodDeploy) * 1000);
    }

    private finishProdDeploy(programId: string, executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];

        this.finish("FINISHED", "production deploy", program, execution);
    }

    private update(execution: any) {
        execution.updatedAt = moment().format();
    }

    private finish(status: string, step: string, program: any, execution: any) {
        this.update(execution);
        execution.status = status;
        execution.finishedAt = moment().format();
        delete execution.runningStep;
        delete program.activeExecutionId[execution.pipelineId];

        const pipeline = this.findPipeline(program.id, execution.pipelineId);
        if (pipeline.type === CiCdPipelineType.production) {
            if (status == "FAILED") {
                this.notifyFailure(program, execution.id, step);
            } else if (status == "FINISHED") {
                this.notifySuccess(program, execution.id, step);
            }
        }

    }

    private notifyFailure(program: any, executionId: string, step: string) {
        this.pulse.addEventFailed("Pipeline Failed", `Pipeline for ${program.title} has failed in the ${step} step.`, [ new Action({
            "url" : `/pipelineexecution.html/organization/${this.imsService.fullOrgId}/program/${program.id}/pipeline/main/execution/${executionId}`
        }) ]);
    }
    private notifySuccess(program: any, executionId: string, step: string) {
        this.pulse.addEventEnd("Pipeline Completed", `Pipeline for ${program.title} has completed successfully.`, [ new Action({
            "url" : `/pipelineexecution.html/organization/${this.imsService.fullOrgId}/program/${program.id}/pipeline/main/execution/${executionId}`
        }) ]);
    }
}