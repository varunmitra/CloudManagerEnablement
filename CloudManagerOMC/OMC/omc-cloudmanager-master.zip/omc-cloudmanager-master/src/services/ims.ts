import { injectable, inject } from "inversify";
import { Request } from "express";
import { TYPES } from "../types";
import { Config } from "./config";
import url from "url";

export interface Ims {

    orgId: string;
    fullOrgId: string;
    authSrc: string;
    userId: string;
    getProfile(req: Request): object;
}

@injectable()
export class ImsImpl implements Ims {

    @inject(TYPES.Config) private config: Config;

    orgId = "972D35F65A8D3C500A495EDE";
    authSrc = "AdobeOrg";
    fullOrgId = `${this.orgId}@${this.authSrc}`;

    userId = "158465F44CD8A8A40A746C1B@AdobeID";

    public getProfile(req: Request) {
        const sessionUrl = url.format({
            protocol: req.protocol,
            hostname: req.hostname,
            port: this.config.getPort(),
            pathname: "/ims/session/v1/MDNjZTJiOTktMjk1MS00ZWYxLThkYzktOTcwMmIwNzI1N2U5LS0xNTg0NjVGNDRDRDhBOEE0MEE3NDZDMUJAQWRvYmVJRA"
          });

          return {
            "account_type": "type1",
            "user_image_url": "https://na1r.services.adobe.com/account/UserImage/?g=158465F44CD8A8A40A746C1B",
            "address": "null, 62 Lincoln Avenue   null null null, Beacon, USA.NY, NY, 12508, US",
            "utcOffset": "null",
            "preferred_languages": [
              "en-us"
            ],
            "displayName": "Justin Edelson",
            "roles": new Array<string>(),
            "last_name": "Edelson",
            "userId": this.userId,
            "projectedProductContext": [
              {
                "prodCtx": {
                  "tenant_id": "weretailprod",
                  "owningEntity": this.fullOrgId,
                  "serviceCode": "dma_tartan",
                  "EMPTY_KEY": "",
                  "ident": "QY544WGY8WC8D92DG9MT4VYY90",
                  "groupid": "35327450",
                  "label": "Adobe Marketing Cloud",
                  "modDts": 1519205467000,
                  "serviceLevel": "standard",
                  "createDts": 1519205467000,
                  "offer_id": "DBFD60C04361444857B80B181767BE62",
                  "geo": "useast",
                  "statusCode": "ACTIVE"
                }
              },
              {
                "prodCtx": {
                  "owningEntity": this.fullOrgId,
                  "serviceCode": "dma_audiencemanager_int",
                  "ident": "J3SCEW0YMWRR85J7B1H2CMWK8G",
                  "groupid": "35327450",
                  "label": "Audience Manager Integration",
                  "modDts": 1519205942000,
                  "serviceLevel": "standard",
                  "deal_id": " ",
                  "createDts": 1519205942000,
                  "offer_id": "",
                  "statusCode": "ACTIVE"
                }
              },
              {
                "prodCtx": {
                  "owningEntity": this.fullOrgId,
                  "serviceCode": "dma_auditor",
                  "ident": "Q0JGBBZ1M3YVTEJD7CR3FMNMQG",
                  "groupid": "35327450",
                  "label": "Auditor",
                  "modDts": 1525097715000,
                  "serviceLevel": "standard",
                  "deal_id": "",
                  "createDts": 1525097715000,
                  "offer_id": "420A3D2FB4ED424CE2FD09FBD7879083",
                  "statusCode": "ACTIVE"
                }
              },
              {
                "prodCtx": {
                  "owningEntity": this.fullOrgId,
                  "serviceCode": "dma_reactor",
                  "ident": "3Y9R830YZ6F928T61YN4B1AD74",
                  "groupid": "35327518",
                  "migration_status": "COMPLETE",
                  "label": "Launch",
                  "modDts": 1519205477000,
                  "serviceLevel": "standard",
                  "createDts": 1519205477000,
                  "offer_id": "89A4BD6416776C71BDD04E0451970A3E",
                  "user_removable": "false",
                  "account_id": "CO7c12340e499f4cb19d4c345d961ae3fc",
                  "account_name": "We.Retail-Prod",
                  "MIGRATE_GROUP_ID": "35327518",
                  "user_visible_name": "Launch - We.Retail-Prod",
                  "statusCode": "ACTIVE"
                }
              },
              {
                "prodCtx": {
                  "owningEntity": this.fullOrgId,
                  "serviceCode": "dma_aem_ams",
                  "ident": "M5NFZMYAFJXBG6JAQC51ETBEYR",
                  "groupid": "35913898",
                  "label": "AEM Managed Services",
                  "modDts": 1520374423000,
                  "serviceLevel": "standard",
                  "createDts": 1520374415000,
                  "offer_id": "C0F9E12A4972C824BAC0CA8795C2920B",
                  "instance_id": "",
                  "MIGRATE_GROUP_ID": "35913898",
                  "deal_id": " ",
                  "statusCode": "ACTIVE"
                }
              },
              {
                "prodCtx": {
                  "owningEntity": "0DE726F85451232F0A4C98A4@AdobeOrg",
                  "serviceCode": "dma_aem_ams",
                  "ident": "6SS427MZ3VXVRHT8WTNFCKC0Z8",
                  "groupid": "36860864",
                  "label": "AEM Managed Services",
                  "modDts": 1501871609000,
                  "enable_sub_service": "dma_aem_ams,user_group_assignment,user_sync,domain_claiming,overdelegation_allowed",
                  "serviceLevel": "standard",
                  "createDts": 1439352802000,
                  "offer_id": "C0F9E12A4972C824BAC0CA8795C2920B",
                  "MIGRATE_GROUP_ID": "5023077",
                  "user_visible_name": "CM_BUSINESS_OWNER_ROLE_PROFILE",
                  "deal_id": "",
                  "statusCode": "ACTIVE"
                }
              },
              {
                "prodCtx": {
                  "owningEntity": this.fullOrgId,
                  "serviceCode": "dma_aem_ams",
                  "ident": "M5NFZMYAFJXBG6JAQC51ETBEYR",
                  "groupid": "37985234",
                  "label": "AEM Managed Services",
                  "modDts": 1520374423000,
                  "serviceLevel": "standard",
                  "createDts": 1520374415000,
                  "offer_id": "C0F9E12A4972C824BAC0CA8795C2920B",
                  "instance_id": "",
                  "MIGRATE_GROUP_ID": "35913898",
                  "user_visible_name": "CM_DEPLOYMENT_MANAGER_ROLE_PROFILE",
                  "deal_id": "",
                  "statusCode": "ACTIVE"
                }
              },
              {
                "prodCtx": {
                  "owningEntity": this.fullOrgId,
                  "serviceCode": "dma_aem_ams",
                  "ident": "M5NFZMYAFJXBG6JAQC51ETBEYR",
                  "groupid": "37985237",
                  "label": "AEM Managed Services",
                  "modDts": 1520374423000,
                  "serviceLevel": "standard",
                  "createDts": 1520374415000,
                  "offer_id": "C0F9E12A4972C824BAC0CA8795C2920B",
                  "instance_id": "",
                  "MIGRATE_GROUP_ID": "35913898",
                  "user_visible_name": "CM_BUSINESS_OWNER_ROLE_PROFILE",
                  "deal_id": "",
                  "statusCode": "ACTIVE"
                }
              }
            ],
            "emailVerified": "true",
            "phoneNumber": "+16467143469",
            "countryCode": "US",
            "name": "Justin Edelson",
            "mrktPerm": "PHONE_RENT:false,EMAIL_RENT:false,EMAIL:true,MAIL_RENT:false,FAX:false,MAIL:true,PHONE:true",
            "mrktPermEmail": "true",
            "first_name": "Justin",
            "email": "jedelson@adobe.com",
            "session": sessionUrl
          };
    }
}