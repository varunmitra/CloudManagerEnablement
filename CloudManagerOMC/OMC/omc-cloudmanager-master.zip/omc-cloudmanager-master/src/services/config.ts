import { argv } from "yargs";
import { injectable } from "inversify";
import path from "path";
import os from "os";
const fs = require("fs-extra");

export enum StepType {
    validate = "validate",
    build = "build",
    codeQuality = "codeQuality",
    buildImage = "buildImage",
    stageDeploy = "stageDeploy",
    securityTest = "securityTest",
    reportPerformanceTest = "reportPerformanceTest",
    prodDeploy = "prodDeploy",
    approval = "approval",
    schedule = "schedule",
    managed = "managed",
    devDeploy = "devDeploy",
    codeGeneration = "codeGeneration",
    unknown = "unknown"
}

export function toStepType(str: string): StepType {
    switch (str) {
        case "validate": return StepType.validate;
        case "build": return StepType.build;
        case "codeQuality": return StepType.codeQuality;
        case "buildImage": return StepType.buildImage;
        case "stageDeploy": return StepType.stageDeploy;
        case "securityTest": return StepType.securityTest;
        case "reportPerformanceTest": return StepType.reportPerformanceTest;
        case "prodDeploy": return StepType.prodDeploy;
        case "approval": return StepType.approval;
        case "schedule": return StepType.schedule;
        case "managed": return StepType.managed;
        case "devDeploy": return StepType.devDeploy;
        case "codeGeneration": return StepType.codeGeneration;
        default: return StepType.unknown;
    }
}

export enum StepPhase {
    build = "build",
    stageDeploy = "stageDeploy",
    prodDeploy = "prodDeploy",
    devDeploy = "devDeploy"
}

export enum Phases {
    build = "build",
    stageDeploy = "stageDeploy",
}

export enum CiCdPipelineType {
    production = "production",
    nonProductionDeploy = "nonProductionDeploy",
    codeQualityOnly = "codeQualityOnly"
}

export interface Config {
    getPort(): number;

    getAuthorUrl(): string;

    getRunbookUrl(): string;

    getPublicDir(): string;

    getMainPipelineName(): string;

    getDuration(stepType: StepType): number;

    getStorageLocation(): string;

    getPublicStorageLocation(): string;

    getValidatePipelineName(): string;

    setDuration(stepType: StepType, duration: number): void;
}

@injectable()
export class ConfigImpl implements Config {

    private rootDir: string;

    private durations: Map<StepType, number> = new Map<StepType, number>();

    constructor() {
        const homeDir = os.homedir();
        this.rootDir = path.join(homeDir, ".omccloudmanager");
        fs.ensureDirSync(this.rootDir);
        this.durations.set(StepType.validate, 5);
        this.durations.set(StepType.build, 5);
        this.durations.set(StepType.buildImage, 10);
        this.durations.set(StepType.stageDeploy, 30);
        this.durations.set(StepType.prodDeploy, 30);
        this.durations.set(StepType.devDeploy, 5);
        this.durations.set(StepType.securityTest, 15);
        this.durations.set(StepType.reportPerformanceTest, 45);
        this.durations.set(StepType.managed, 15);
        this.durations.set(StepType.codeGeneration, 15);
    }

    public setDuration(stepType: StepType, duration: number) {
        this.durations.set(stepType, duration);
    }

    public getStorageLocation() {
        return this.rootDir;
    }

    public getPublicStorageLocation() {
        return path.join(this.rootDir, "public");
    }

    public getPort() {
        return 3000;
    }

    public getAuthorUrl() {
        return argv.aemUrl || "https://author-weretail-global-prod.adobecqms.net/";
    }

    public getRunbookUrl() {
        return argv.runbookUrl || "https://adobe.sharepoint.com/sites/ams/geometrixxcqms/SitePages/CQMS_Runbook.aspx";
    }

    public getPublicDir() {
        return path.join(__dirname, "..", "public");
    }

    public getMainPipelineName() {
        return "main";
    }

    public getValidatePipelineName() {
        return "update-validate";
    }

    public getDuration(stepType: StepType) {
        if (this.durations.has(stepType)) {
            return this.durations.get(stepType);
        } else {
            return 0;
        }
    }


}