import { injectable } from "inversify";
import * as _ from "lodash";
import notificationTypes from "../data/notification-types.json";
import baseNotifications from "../data/notifications.json";
import { v4 } from "uuid";
import { BaseResettable, Resettable } from "./resettable";
const dateformat = require("dateformat");

export interface Pulse extends Resettable {
    getTypes(): any[];

    getUnreadPostCount(type?: string): number;

    getPosts(): any[];

    addEventStart(title: string, description: string, actions: Action[]): any;

    addEventFailed(title: string, description: string, actions: Action[]): any;

    addEventEnd(title: string, description: string, actions: Action[], iconType?: string, iconColor?: string): any;

    addActionRequired(title: string, description: string, iconType: string, iconColor: string, actions: Action[]): any;

    getPost(postId: string): any;
}

export class Action {
    public actionId =  "linkCustomId";
    public actionTaken: false;
    public actionType = "link";
    public displayValue = "View Details";
    public eventName: string;
    public eventType = "click";
    public isPrimary = true;
    public url: string;

    constructor(obj: any) {
        _.merge(this, obj);
    }
}

@injectable()
export class PulseImpl extends BaseResettable implements Pulse {

    private notifications: any;

    public getTypes(): any[] {
        return notificationTypes;
    }

    public getUnreadPostCount(type?: string) {
        let filter;
        if (type) {
            filter = function(post: any) {
                return post.type.primaryType === type && !post.isRead;
            };
        } else {
            filter = function(post: any) {
                return !post.isRead;
            };
        }
        let result = 0;
        _.each(_.filter(this.notifications.posts, filter), function() {
            result++;
        });
        return result;
    }

    public getPosts(): any[] {
        return this.notifications.posts;
    }

    public getPost(postId: string): any {
        return _.find(this.notifications.posts, (post) => {
            return post.postKey == postId;
        });
    }

    public addEventStart(title: string, description: string, actions: Action[], iconType = "publish", iconColor = "#a5d273"): any {
        const postKey = this.newPostKey();
        const newPost = {
            "actionsList": <any[]>[],
            "blobData": <any[]>[],
            "channel": "",
            "channelDetailsMap": {},
            "commentsCount": 0,
            "creationTs": dateformat(new Date(), "UTC:yyyy-mm-dd'T'HH:MM:ss.lll'Z'"),
            "creator": "@[\"test\":\"test\"]",
            "customProp": {},
            "description": description,
            "iconColor": iconColor,
            "iconType": iconType,
            "isFavorite": false,
            "isFlagged": false,
            "isRead": false,
            "lastCommentDetail": { },
            "lastUpdateTs": dateformat(new Date(), "UTC:yyyy-mm-dd'T'HH:MM:ss.lll'Z'"),
            "orgId": "9AAA4E8A51F29C140A490D4C@AdobeOrg",
            "postKey": postKey,
            "sharePostKey": postKey,
            "sharedGroupNames": JSON.parse("[]"),
            "solutionOrg": "",
            "success": true,
            "targetSolution": "all",
            "title": title,
            "type": {
                "grouping": {},
                "primaryType": "EVENT_START"
            }
        };

        if (actions) {
            newPost.actionsList = actions;
        }

        this.notifications.posts.unshift(newPost);
        return newPost;
    }

    public addEventFailed(title: string, description: string, actions: Action[]) {
        const postKey = this.newPostKey();
        const newPost = {
            "actionsList": <any[]>[],
            "blobData": <any[]>[],
            "channel": "",
            "channelDetailsMap": {},
            "commentsCount": 0,
            "creationTs": dateformat(new Date(), "UTC:yyyy-mm-dd'T'HH:MM:ss.lll'Z'"),
            "creator": "@[\"test\":\"test\"]",
            "customProp": {},
            "description": description,
            "iconColor": "#fa7369",
            "iconType": "publishReject",
            "isFavorite": false,
            "isFlagged": false,
            "isRead": false,
            "lastCommentDetail": { },
            "lastUpdateTs": dateformat(new Date(), "UTC:yyyy-mm-dd'T'HH:MM:ss.lll'Z'"),
            "orgId": "9AAA4E8A51F29C140A490D4C@AdobeOrg",
            "postKey": postKey,
            "sharePostKey": postKey,
            "sharedGroupNames": JSON.parse("[]"),
            "solutionOrg": "",
            "success": true,
            "targetSolution": "all",
            "title": title,
            "type": {
                "grouping": {},
                "primaryType": "EVENT_FAILED"
            }
        };

        if (actions) {
            newPost.actionsList = actions;
        }

        this.notifications.posts.unshift(newPost);
        return newPost;
    }

    public addEventEnd(title: string, description: string, actions: Action[]) {
        const postKey = this.newPostKey();
        const newPost = {
            "actionsList": <any[]>[],
            "blobData": <any[]>[],
            "channel": "",
            "channelDetailsMap": {},
            "commentsCount": 0,
            "creationTs": dateformat(new Date(), "UTC:yyyy-mm-dd'T'HH:MM:ss.lll'Z'"),
            "creator": "@[\"test\":\"test\"]",
            "customProp": {},
            "description": description,
            "iconColor": "#a5d273",
            "iconType": "publishCheck",
            "isFavorite": false,
            "isFlagged": false,
            "isRead": false,
            "lastCommentDetail": { },
            "lastUpdateTs": dateformat(new Date(), "UTC:yyyy-mm-dd'T'HH:MM:ss.lll'Z'"),
            "orgId": "9AAA4E8A51F29C140A490D4C@AdobeOrg",
            "postKey": postKey,
            "sharePostKey": postKey,
            "sharedGroupNames": JSON.parse("[]"),
            "solutionOrg": "",
            "success": true,
            "targetSolution": "all",
            "title": title,
            "type": {
                "grouping": {},
                "primaryType": "EVENT_END"
            }
        };

        if (actions) {
            newPost.actionsList = actions;
        }

        this.notifications.posts.unshift(newPost);
        return newPost;
    }

    public addActionRequired(title: string, description: string, iconType: string, iconColor: string, actions: Action[]) {
        const postKey = this.newPostKey();
        const newPost = {
            "actionsList": <any[]>[],
            "blobData": <any[]>[],
            "channel": "",
            "channelDetailsMap": {},
            "commentsCount": 0,
            "creationTs": dateformat(new Date(), "UTC:yyyy-mm-dd'T'HH:MM:ss.lll'Z'"),
            "creator": "@[\"test\":\"test\"]",
            "customProp": {},
            "description": description,
            "iconColor": iconColor,
            "iconType": iconType,
            "isFavorite": false,
            "isFlagged": false,
            "isRead": false,
            "lastCommentDetail": { },
            "lastUpdateTs": dateformat(new Date(), "UTC:yyyy-mm-dd'T'HH:MM:ss.lll'Z'"),
            "orgId": "9AAA4E8A51F29C140A490D4C@AdobeOrg",
            "postKey": postKey,
            "sharePostKey": postKey,
            "sharedGroupNames": JSON.parse("[]"),
            "solutionOrg": "",
            "success": true,
            "targetSolution": "all",
            "title": title,
            "type": {
                "grouping": {},
                "primaryType": "ACTION_REQUIRED"
            }
        };

        if (actions) {
            newPost.actionsList = actions;
        }

        this.notifications.posts.unshift(newPost);
        return newPost;
    }

    private newPostKey(): string {
        return "key" + v4().replace(/\-/g, "");
    }

    public reset() {
        this.notifications = _.cloneDeep(baseNotifications);
        this.invokeInitHooks();
    }
}