import { injectable } from "inversify";

@injectable()
export abstract class BaseService {

}