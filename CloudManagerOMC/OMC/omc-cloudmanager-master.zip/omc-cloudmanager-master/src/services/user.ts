import { controller, httpGet } from "inversify-express-utils";
import { BaseService } from "./base";
import { User } from "../models";
import { Ims } from "./ims";
import { TYPES } from "../types";
import { inject } from "inversify";

export interface UserService {
    getMe(): User;
}

@controller("/api")
export class UserServiceImpl extends BaseService implements UserService {
    @inject(TYPES.Ims) private imsService: Ims;

    @httpGet("/program/:programId/user/me")
    public getMe() {
        const user = new User();
        user.username = this.imsService.userId;
        user._embedded = {
            permissions: ["EXECUTION_CANCEL", "EXECUTION_CREATE", "SOLUTION_WRITE", "PIPELINE_CREATE", "REPOSITORY_WRITE", "STEP_READ", "ENVIRONMENT_READ", "PIPELINE_READ", "PIPELINE_MODIFY_APPROVAL", "PIPELINE_MODIFY_MANAGED_DEPLOYMENT", "PIPELINE_DELETE", "EXECUTION_SCHEDULE_DEPLOY_TO_PRODUCTION", "STEP_WRITE", "APPLICATION_WRITE", "EXECUTION_WRITE", "APPLICATION_READ", "EXECUTION_READ", "REPOSITORY_CODE_GENERATOR", "STEP_CANCEL", "EXECUTION_RESUME", "PIPELINE_WRITE", "EXECUTION_OVERRIDE_3T_FAILURES", "REPOSITORY_READ", "SOLUTION_READ", "ON_DEMAND_SCALE_PROD", "ON_DEMAND_SCALE_NON_PROD", "EXECUTION_APPROVE_DEPLOY_TO_PRODUCTION"],
            roles: ["User", "DeploymentManager", "BusinessOwner"]
        };
        return user;
    }
}