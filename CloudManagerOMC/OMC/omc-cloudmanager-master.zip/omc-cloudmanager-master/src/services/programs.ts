import { BaseService } from "./base";
import * as _ from "lodash";
import { injectable } from "inversify";
import basePrograms from "../data/programs.json";
import { Resettable, InitHook, BaseResettable } from "./resettable";

export interface ProgramService extends Resettable {

    getAllRawPrograms(): any[];

    getRawProgram(id: string): any;
}

@injectable()
export class ProgramServiceImpl extends BaseResettable implements ProgramService {

    private programs: object[];

    public getAllRawPrograms() {
        return this.programs;
    }

    public reset() {
        this.programs = _.cloneDeep(basePrograms);
        this.invokeInitHooks();
    }

    public getRawProgram(programId: string): any {
        return _.find(this.programs, (p: any) => {
            return p.id === programId;
        });
    }

}

