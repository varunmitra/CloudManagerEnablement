export class MetricDefinition {
    name: string;
    state: string;
    stateDetails: string;
    warningThreshold: number;
    criticalThreshold: number;
    id: string;
    category: string;
    label?: string;
    baselineValue?: number;
    subMetrics?: SubMetric[];
    labelToThresholds: any;
    modifications?: Modification[];
    uom?: string;
}

class SubMetric {
    label: string;
    baselineValue: number;
}

export class Modification {
    point: number;
    type: ModificationType;
    factor: number;

}

export enum ModificationType {
    factor
}

function loadPerCore(load1: number, load2: number, load3: number): MetricDefinition {
    return {
        "name": "Load Per Core",
        "state": "OK",
        "stateDetails": "OK - load average: 0.10, 0.09, 0.10",
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": "load_per_core",
        "category": "Host",
        "subMetrics" : [
            { label: "load1", baselineValue: load1 },
            { label: "load5", baselineValue: load2 },
            { label: "load15", baselineValue: load3 }
        ],
        "labelToThresholds" : {
            load1: { warn: "15.0", crit: "18.0", "min": "0"},
            load5: { warn: "10.0", crit: "13.0", "min": "0"},
            load15: { warn: "5.0", crit: "7.0", "min": "0"},
        },
        "modifications" : [
            {
                point: 30,
                type: ModificationType.factor,
                factor: 21.5
            },
            {
                point: 180,
                type: ModificationType.factor,
                factor: 0.3
            }
        ]
    };
}

function diskSpace(slash: number, mnt: number): MetricDefinition {
    return {
        "name": "Disk Space",
        "state": "OK",
        "stateDetails": "DISK OK - free space: / 22913 MB (74% inode=99%): /mnt 40412 MB (84% inode=99%):",
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": "disk_space",
        "category": "Storage",
        "subMetrics" : [
            { label: "/", baselineValue: slash },
            { label: "/mnt", baselineValue: mnt }
        ],
        "labelToThresholds" : {
            "/": {warn: "18424", crit: "21494", min: "0", max: "30707"},
            "/mnt": {warn: "30158", crit: "35184", min: "0", max: "50264"}
        },
        uom: "MB"
    };
}

function processCount(count: number): MetricDefinition {
    return {
        "name": "Process Count",
        "state": "OK",
        "stateDetails": "PROCS OK: 109 processes",
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": "process_count",
        "category": "Host",
        "label" : "procs",
        "baselineValue": count,
        labelToThresholds: {
            procs: {warn: "1000", crit: "1500", min: "0"}
        }
    }
}

function ntpSync(): MetricDefinition {
    return {
        "name": "NTP Sync",
        "state": "OK",
        "stateDetails": "OK - (no problem found)",
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": "ntp_sync",
        "category": "Network",
        labelToThresholds: {}
    };
}

function userCount(count: number): MetricDefinition {
    return {
        "name": "User Count",
        "state": "OK",
        "stateDetails": `USERS OK - ${count} users currently logged in`,
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": "user_count",
        "category": "Host",
        "label" : "users",
        "baselineValue": count,
        labelToThresholds: {
            users: {warn: "5", crit: "10", min: "0"}
        }
    };
}

function memoryUsage(count: number): MetricDefinition {
    return {
        "name": "Memory Usage",
        "state": "OK",
        "stateDetails": `OK: Memory Usage Percentage: ${count}%`,
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": "memory_usage",
        "category": "Host",
        "label": "Memory Usage Percentage",
        "baselineValue" : count,
        labelToThresholds: {
            "Memory Usage Percentage": {warn: "95", crit: "98", min: "0", max: "100"}
        },
        uom: "%"
    };
}

function portCheck(port: number, duration: number): MetricDefinition {
    return {
        "name": `CQ Port ${port} Check`,
        "state": "OK",
        "stateDetails": `TCP OK - ${duration} second response time on 35.168.87.130 port ${port}`,
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": `cq_port_${port}_check`,
        "category": "Network",
        "label": "time",
        baselineValue: duration,
        "labelToThresholds" : {
            time: {min: "0.000000", max: "10.000000"}
        },
        "uom": "s"
    }
}

function jvmMemory(pid: number, heap: number, perm: number): MetricDefinition {
    return {
        "name": `JVM Memory`,
        "state": "OK",
        "stateDetails": `OK: jstat process ${pid} alive`,
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": `jvm_memory`,
        "category": "Host",
        "subMetrics" : [
            { label: "pid", baselineValue: pid },
            { label: "heap", baselineValue: heap }
        ],
        labelToThresholds: {
            heap: {warn: "3400000", crit: "3770000"},
            pid: {}
        }
    }
}

function oldGeneration(percent: number): MetricDefinition {
    return {
        "name": `Old Generation Space`,
        "state": "OK",
        "stateDetails": `OK: The old generation size is 589877KB (This is ${percent} percent of 2097152.0KB total)`,
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": `old_generation_space`,
        "category": "Host",
        "label": "size",
        baselineValue: percent,
        labelToThresholds: {
            size: {warn: "95", crit: "98", min: "0", max: "100"}
        },
        uom: "%"
    }
}

function dispatcherFlush(inQueue: number): MetricDefinition {
    return {
        "name": `Dispatcher Flush`,
        "state": "OK",
        "stateDetails": `OK: ${inQueue} items in flush queue`,
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": `dispatcher_flush`,
        "category": "Application",
        "label": "Items in flush queue",
        baselineValue: inQueue,
        labelToThresholds : {
            "Items in flush queue": {warn: "100", crit: "200", min: "0", max: "45000"}
        },
        "uom": "items"
    }
}

class AgentConfig {
    name: string;
    baselineValue: number;
}

function replicationAgent(agents: AgentConfig[]): MetricDefinition {
    const thresholds: any = {};
    agents.forEach(a => {
        thresholds[a.name] = {warn: "5", crit: "8"}
    });
    return {
        "name": `Replication Agent`,
        "state": "OK",
        "stateDetails": `OK: All agents healthy: ${agents.map(a => a.name).join(" ")}`,
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": `replication_agent`,
        "category": "Application",
        "subMetrics" : agents.map(a => { return { label: a.name, baselineValue: a.baselineValue} }),
        labelToThresholds: thresholds,
        "uom": "s"
    }
}

function segmentStore(size: number): MetricDefinition {
    return {
        "name": "Folder Size: AEM SegmentStore",
        "state": "OK",
        "stateDetails": "OK: The folder size is 0.26231GB (This is 0.534384 % of total /mnt volume)",
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": "folder_size_aem_segmentstore",
        "category": "Storage",
        baselineValue: size,
        label: "size",
        labelToThresholds: {
            size: {warn: "2540", crit: "5642", min: "0", max: "50265"}
        },
        uom: "GB"
    };
}

function onlineCompaction(): MetricDefinition {
    return {
        "name": "Online Compaction",
        "state": "OK",
        "stateDetails": "OK: OnRC has run: OK: OnRC process OK: OK: BlobGC has run",
        "warningThreshold": -1.0,
        "criticalThreshold": -1.0,
        "id": "online_compaction",
        "category": "Application",
        labelToThresholds: {}
    };
}

export function getDispatcherMetrics() {
    return [
        loadPerCore(0.10, 0.07, 0.20),
        diskSpace(5287, 13720),
        processCount(117),
        ntpSync(),
        userCount(0),
        memoryUsage(10),
        portCheck(80, 0.079)
    ];
}

export function getPublishMetrics() {
    return [
        loadPerCore(0.20, 0.15, 0.25),
        diskSpace(8542, 10000),
        processCount(112),
        ntpSync(),
        userCount(0),
        memoryUsage(50),
        portCheck(4503, 0.062),
        jvmMemory(4500, 987016.20417, 136849.99639),
        oldGeneration(28),
        dispatcherFlush(2),
        onlineCompaction(),
        segmentStore(0.27)
    ];
}

export function getAuthorMetrics(publishNames: string[]) {
    return [
        loadPerCore(0.26, 0.20, 0.30),
        diskSpace(7438, 20430),
        processCount(120),
        ntpSync(),
        userCount(0),
        memoryUsage(72),
        portCheck(4502, 0.083),
        jvmMemory(4500, 1810000, 147849.99639),
        oldGeneration(32),
        onlineCompaction(),
        replicationAgent(publishNames.map(n => {
            return {
                name: n,
                baselineValue: 0.02
            };
        })),
        segmentStore(0.84)
    ]
}
