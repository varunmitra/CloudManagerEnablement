export function isCloud(program: any): boolean {
    return (program.capabilities && program.capabilities.cloud);
}