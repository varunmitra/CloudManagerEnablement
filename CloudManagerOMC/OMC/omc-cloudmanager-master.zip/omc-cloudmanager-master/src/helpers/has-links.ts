import { BaseModel } from "../models/base-model";
import { HalLink } from "../models";

export abstract class HasLinks extends BaseModel {

    _links: any;

    constructor() {
        super();
        this._links = {};
    }

    addLink(type: string, href: string, templated: boolean = false) {
        if (!this._links) {
            this._links = {};
        }
        const link = new HalLink();
        link.href = href;
        link.templated = templated;
        this._links[type] = link;
    }

    addSelf(href: string) {
        this.addLink("self", href);
    }
}