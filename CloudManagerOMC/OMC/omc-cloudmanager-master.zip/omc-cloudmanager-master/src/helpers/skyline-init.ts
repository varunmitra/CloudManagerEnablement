import { Pulse, Action } from "../services/pulse";
import { Ims } from "../services/ims";
import { ProgramService } from "../services/programs";
import moment = require("moment");
import { Config, StepType } from "../services/config";

export class SkylineHelper {

    public initPrograms(programService: ProgramService) {
        const program = programService.getAllRawPrograms().forEach(program => program.capabilities = { cloud: true});
    }

}