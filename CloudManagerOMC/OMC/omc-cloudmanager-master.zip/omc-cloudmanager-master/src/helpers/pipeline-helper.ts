import * as _ from "lodash";
import { PipelineExecutionStepState, pipelineExecutionStepState_status, Metric, pipelineExecution_status } from "../models";

export function ceil(x: number, y: number): number {
    if (x < y) {
        return y;
    } else {
        return x;
    }
}

export function priorStepFailed(stepStates: PipelineExecutionStepState[]): boolean {
    return !_.isUndefined(stepStates.find(stepState => (stepState.status == pipelineExecutionStepState_status.FAILED || stepState.status == pipelineExecutionStepState_status.CANCELLED)));
}

export function setMetricResult(metrics: Metric[], id: string, actualValue: string, passed: boolean, override: boolean) {
    const metric = _.find(metrics, (metric) => {
        return metric.id == id;
    });
    metric.actualValue = actualValue;
    metric.passed = passed;
    metric.override = override;
}

export function isRunning(rawExecution: any): boolean {
    return rawExecution.status == pipelineExecution_status.CANCELLING ||
            rawExecution.status == pipelineExecution_status.RUNNING ||
            rawExecution.status == pipelineExecution_status.WAITING_FOR_INPUT;
}

export function isPriorStepRunning(rawExecution: any, stepStates: PipelineExecutionStepState[]): boolean {
    return !_.isUndefined(stepStates.find(stepState => stepState.id === rawExecution.runningStep));
}