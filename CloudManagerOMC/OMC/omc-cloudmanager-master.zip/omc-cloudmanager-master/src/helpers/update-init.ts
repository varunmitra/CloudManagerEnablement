import { Pulse, Action } from "../services/pulse";
import { Ims } from "../services/ims";
import { ProgramService } from "../services/programs";
import moment = require("moment");
import { Config, StepType } from "../services/config";

export class UpdateHelper {

    public initPulse(pulse: Pulse, ims: Ims) {
        pulse.addActionRequired("AEM Product Update available", "A new AEM update is available for We.Retail Global that will significantly enhance your experience.",
            "refresh", "#3375de", [
            new Action({
                url: `/update.html/organization/${ims.fullOrgId}/program/weretail-global`
            })
        ]);
    }

    public initPrograms(programService: ProgramService) {
        const program = programService.getRawProgram("weretail-global");
        program.pipeline.branch = "master";
        program.executions["6"].stepsRequiringOverride = [];

        program["updateState"] = {
            "status": "ready",
            "showSandbox": true
        };
    }

    public initConfig(config: Config) {
        config.setDuration(StepType.stageDeploy, 10);
        config.setDuration(StepType.prodDeploy, 10);
        config.setDuration(StepType.reportPerformanceTest, 15);
        config.setDuration(StepType.securityTest, 5);
    }

}