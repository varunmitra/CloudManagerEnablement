const opn = require("opn");

import { app } from "./app";

app.listen(app.get("port"), () => {
  console.log(
    "  OMC Cloud Manager listening on port %d",
    app.get("port")
  );
  opn(`http://localhost:${app.get("port")}`);
  console.log("  Press CTRL-C to stop\n");
});
