import "reflect-metadata";

import { Container } from "inversify";

import { interfaces, InversifyExpressServer, TYPE, getRouteInfo } from "inversify-express-utils";
import errorHandler from "errorhandler";
import express from "express";
import path from "path";
import cors from "cors";
import process from "process";

import * as _ from "lodash";
import * as bodyParser from "body-parser";
const fileUpload = require("express-fileupload");

import { Config, ConfigImpl } from "./services/config";
import { Ims, ImsImpl } from "./services/ims";
import { ProgramService, ProgramServiceImpl } from "./services/programs";
import { UserServiceImpl, UserService } from "./services/user";
import { PulseImpl, Pulse } from "./services/pulse";
import { PipelineService, PipelineServiceImpl } from "./services/pipeline";

import { TYPES } from "./types";

import "./controllers/root_controller";
import "./controllers/admin_controller";
import "./controllers/ims_controller";
import "./controllers/environments_controller";
import "./controllers/programs_controller";
import "./controllers/pipelines_controller";
import "./controllers/pulse_controller";
import "./controllers/executions_controller";
import "./controllers/update_controller";

export const container = new Container();
container.bind<Config>(TYPES.Config).to(ConfigImpl).inSingletonScope();
container.bind<Ims>(TYPES.Ims).to(ImsImpl).inSingletonScope();
container.bind<ProgramService>(TYPES.ProgramService).to(ProgramServiceImpl).inSingletonScope();
container.bind<UserService>(TYPES.UserService).to(UserServiceImpl).inSingletonScope();
container.bind<Pulse>(TYPES.Pulse).to(PulseImpl).inSingletonScope();
container.bind<PipelineService>(TYPES.PipelineService).to(PipelineServiceImpl).inSingletonScope();

const config: Config = container.get(TYPES.Config);

function shutdown(callback: () => void) {
  console.log("Goodbye");
  callback();
}

process.on("SIGINT", function () {
  shutdown(() => {
    process.exit();
  });
});

// create server
const server = new InversifyExpressServer(container);
server.setConfig((app) => {
  app.set("port", config.getPort());
  app.use(cors());
  app.set("views", path.join(__dirname, "../views"));
  app.set("view engine", "ejs");
  app.use((req, res: any, next) => {
    const oldSend = res.send;

    res.send = function() {
        if (_.isUndefined(arguments[0])) {
          arguments[0] = 404;
        }
        oldSend.apply(res, arguments);
    };
    next();
  });
  app.use((req, res, next) => {
    if (req.url.match(/\/.*\.html(\/.*)?/)) {
      req.url = "/index.html";
    }
    next();
  });
  // add body parser
  app.use(bodyParser.urlencoded({
    extended: true
  }));
  app.use(bodyParser.json());
  app.use(fileUpload({
    limits: { fileSize: 50 * 1024 * 1024 }
  }));
  app.use(express.static(config.getPublicDir(), {
    setHeaders: function (res, path, stat) {
      if (path.endsWith(".log") || path.endsWith(".pdf")) {
        res.set("Content-Disposition", "attachment");
      }
    }
  }));
  app.use(express.static(config.getPublicStorageLocation(), {
    setHeaders: function (res, path, stat) {
      if (path.endsWith(".log")) {
        res.set("Content-Disposition", "attachment");
      }
    }
  }));
});

export const app = server.build();