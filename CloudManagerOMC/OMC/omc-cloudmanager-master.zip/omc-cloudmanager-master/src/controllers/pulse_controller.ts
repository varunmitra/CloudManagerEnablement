import { controller, BaseHttpController, httpGet, requestParam, httpPost, requestBody } from "inversify-express-utils";
import { TYPES } from "../types";
import { Pulse } from "../services/pulse";
import { inject } from "inversify";
import * as _ from "lodash";
import { Request } from "express";

@controller("/pulse")
class PulseController extends BaseHttpController {
    @inject(TYPES.Pulse) private pulse: Pulse;

    @httpGet("/:tenantId@AdobeOrg/marketingcloud/v1/notifications/types")
    public getNotificationTypes(@requestParam("tenantId") tenantId: string) {
        return {
            tenantId: tenantId,
            success: true,
            totalUnreadCount: this.pulse.getUnreadPostCount(),
            types: _.map(this.pulse.getTypes(), (type) => {
                return {
                    typeName: type.name,
                    totalUnreadCount: this.pulse.getUnreadPostCount(type.id),
                    typeId: type.id
                };
            })
        };
    }

    @httpGet("/:tenantId@AdobeOrg/marketingcloud/v1/notifications/userdata")
    public getUserData(@requestParam("tenantId") tenantId: string) {
        return {
            success: true,
            recentSearch: "[]"
        };
    }

    @httpGet("/:tenantId/marketingcloud/v1/notifications")
    public getNotifications(@requestParam("tenantId") tenantId: string, req: Request) {
        let posts = this.pulse.getPosts();
        let startTimeStamp = 0;
        if (req.query.pageOffset) {
            startTimeStamp = parseInt(req.query.pageOffset);
        }
        posts = _.filter(posts, function(post) {
            return (new Date(post.creationTs).getTime() > startTimeStamp);
        });
        let endTimeStamp = 0;
        if (posts.length > 0) {
            endTimeStamp = new Date(_.first(posts).creationTs).getTime();
        }

        return {
            pageOffset: `${startTimeStamp}`,
            previousPageOffset: `${endTimeStamp}`,
            success: true,
            notifications: _.map(posts, this.asNotification)
        };
    }

    @httpGet("/:tenantId/marketingcloud/v1/notifications/:postId/posts")
    public getPost(@requestParam("postId") postId: string, req: Request) {
        let post = this.pulse.getPost(postId);
        if (!post) {
            return 404;
        }

        post = _.cloneDeep(post);
        if (post.actionsList) {
            _.each(post.actionsList, function(action) {
                action.url = "http://" + req.headers.host + action.url;
            });
        }

        return {
            "notification" : this.asNotification(post),
            "notificationKey" : req.params.postId,
            "posts" : [
                post
            ]
        };
    }

    @httpPost("/:tenantId/marketingcloud/v1/notifications/:postId")
    public updatePost(@requestParam("postId") postId: string, @requestBody() body: any) {
        if (body.action == "read") {
            const post = this.pulse.getPost(postId);
            if (post) {
                post.isRead = true;
            }
        }
        return 200;
    }

    private asNotification = (post: any) => {
        return {
            creationTs : post.creationTs,
            iconColor : post.iconColor,
            iconType : post.iconType,
            isFlagged : post.isFlagged,
            notificationKey : post.postKey,
            title : post.title,
            totalCount : 1,
            totalUnreadCount : post.isRead ? 0 : 1,
            type : post.type.primaryType,
            description : post.description
        };
    };
}