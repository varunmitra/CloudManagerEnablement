import { injectable, inject } from "inversify";
import {
    controller, httpGet, BaseHttpController, HttpResponseMessage, StringContent, httpPost
} from "inversify-express-utils";
import { Ims } from "../services/ims";
import { TYPES } from "../types";
import { Request, Response } from "express";

@controller("/ims")
class ImsController extends BaseHttpController {

    @inject(TYPES.Ims) private imsService: Ims;

    private sendWithCallbackIfNecessary(data: any) {
        const req = this.httpContext.request;
        const res = this.httpContext.response;

        if (req.query.callback) {
            res.set("Content-Type", "application/javascript");
            res.send(`${req.query.callback}(${JSON.stringify(data)})`);
        } else {
            res.send(data);
        }
    }

    @httpGet("/imslib.js")
    public getImsLib() {
        this.httpContext.response.render("ims/imslib", {
            profileData : JSON.stringify(this.imsService.getProfile(this.httpContext.request))
        });
    }

    @httpGet("/session/v1/:sessionId")
    public getSession() {
        const data = {
            "session_data": {
              "current_active_org": { "org_id": this.imsService.orgId, "org_auth_src": this.imsService.authSrc }
            }
        };
        this.sendWithCallbackIfNecessary(data);
    }

    @httpPost("/session/v1/:sessionId")
    public async updateSession() {
        return this.ok();
    }

    @httpGet("/organizations/v1")
    public getOrganizations() {
        const data = {
            "orgs":
              [
                {
                  "orgName": "We.Retail-Prod",
                  "orgRef": { "ident": this.imsService.orgId, "authSrc": this.imsService.authSrc },
                  "groups": [
                    { "groupName": "Administrators", "role": "GRP_ADMIN", "ident": 35327462 },
                    { "groupName": "Support Administrators", "role": "TEAM_MEMBER", "ident": 35910418 },
                    { "groupName": "AEM Managed Services - ", "role": "TEAM_MEMBER", "ident": 35913898 },
                    { "groupName": "M5NFZMYAFJXBG6JAQC51ETBEYR_PRODUCT_ADMIN_GROUP_NAME_SUFFIX", "role": "TEAM_MEMBER", "ident": 35915514 }
                  ]
                }
              ]
          };

          this.sendWithCallbackIfNecessary(data);
    }

    @httpGet("/profile/v1")
    public getProfile() {
        this.sendWithCallbackIfNecessary(this.imsService.getProfile(this.httpContext.request));
    }
}