import { injectable, inject } from "inversify";
import {
    controller, httpGet, BaseHttpController, HttpResponseMessage, StringContent, httpPost
} from "inversify-express-utils";
import { TYPES } from "../types";
import { ProgramService } from "../services/programs";
import { Pulse } from "../services/pulse";
const child_process = require("child_process");

@controller("/")
class AdminController extends BaseHttpController {
    @inject(TYPES.ProgramService) private programService: ProgramService;
    @inject(TYPES.Pulse) private pulse: Pulse;

    @httpGet("reset")
    public reset() {
        this.programService.reset();
        this.pulse.reset();
        return this.redirect("/index.html");
    }

    @httpGet("debug")
    public debug() {
        this.httpContext.response.type("text/plain");
        return JSON.stringify(this.programService.getAllRawPrograms(), undefined, 4);
    }

    @httpPost("update")
    public update() {
        const options = {
            stdio: [0, 1, 2],
            cwd: __dirname
        };

        child_process.execSync("git pull", options);
        child_process.execSync("npm install", options);
        child_process.execSync("npm run build", options);
        process.exit(0);
        return {};
    }
}