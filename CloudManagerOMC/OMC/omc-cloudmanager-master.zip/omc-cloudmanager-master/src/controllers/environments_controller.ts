import { TYPES } from "../types";
import { ProgramService } from "../services/programs";
import { controller, BaseHttpController, httpGet, requestParam, requestBody, httpPut, queryParam } from "inversify-express-utils";
import { inject } from "inversify";
import { EnvironmentList, Environment, InstanceList, EnvironmentInstance, IEnvironmentInstance, ListofMonitoringMetricData, Monitoringmetricdata, InstanceMonitoringList } from "../models";
import * as _ from "lodash";
import { RELS } from "../rels";
import moment = require("moment");
import { getAuthorMetrics, getDispatcherMetrics, getPublishMetrics, MetricDefinition, Modification, ModificationType } from "../data/monitoring-metrics";

@controller("/api")
class EnvironmentsController extends BaseHttpController {

    @inject(TYPES.ProgramService) private programService: ProgramService;

    @httpGet("/program/:programId/environments")
    public list(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program) {
            const result = new EnvironmentList();

            if (program.environments) {
                result._totalNumberOfItems = program.environments.length;

                const embeddedEnvironments: Environment[] = [];

                _.each(program.environments, (env) => {
                    const embedded = new Environment();
                    embedded.id = env.name;
                    embedded.name = env.name;
                    embedded.programId = programId;
                    embedded.type = env.type;
                    embedded.addLink(RELS.instances, `/api/program/${programId}/environment/${env.name}/instances`);
                    embedded.addLink(RELS.instanceMetrics, `/api/program/${programId}/environment/${env.name}/instances/metrics`);
                    embedded.addLink(RELS.program, `/api/program/${programId}`);
                    embedded.addSelf(`/api/program/${programId}/environment/${env.name}`);

                    embeddedEnvironments.push(embedded);
                });

                result._embedded = {
                    environments: embeddedEnvironments
                };
            }

            result.addSelf(`/api/program/${programId}/environments`);

            return result;
        }
        return undefined;
    }

    @httpGet("/program/:programId/environment/:envName/instances")
    public listInstances(@requestParam("programId") programId: string, @requestParam("envName") envName: string) {
        const program = this.programService.getRawProgram(programId);
        if (program) {
            const env = _.find(program.environments, e => e.name === envName);
            if (env) {
                const result = new InstanceList();
                const inInstances = this.getRawInstances(env);

                const instances: IEnvironmentInstance[] = inInstances.map((i: any) => {
                    return new EnvironmentInstance({
                        name: i.name,
                        cloudProvider: "AWS",
                        instanceSize: "m5.large",
                        region: "us-east-1",
                        status: env.status,
                        storageSize: this.getSize(env.type),
                        type: i.type.toUpperCase()
                    });
                });

                result._embedded = {
                    instances: instances
                };
                result._totalNumberOfItems = instances.length;
                result.addSelf(`/api/program/${programId}/environments/${envName}/instances`);

                return result;
            }
        }
        return undefined;
    }

    @httpGet("/program/:programId/environment/:envName/instances/metrics")
    public getMetrics(@requestParam("programId") programId: string, @requestParam("envName") envName: string) {
        const program = this.programService.getRawProgram(programId);
        if (program) {
            const env = _.find(program.environments, e => e.name === envName);
            if (env) {
                const result = new InstanceMonitoringList();
                const inInstances = this.getRawInstances(env);

                const instances: any[] = inInstances.map((i: any) => {
                    const result: any = {
                        name: i.name,
                        status: env.status,
                        hostName: i.hostName,
                        type: i.type.toUpperCase()
                    };
                    this.populateMetrics(programId, envName, result, inInstances);
                    return result;
                });

                result._embedded = {
                    instances: instances
                };
                result._totalNumberOfItems = instances.length;
                result.addSelf(`/api/program/${programId}/environments/${envName}/instances`);

                return result;
            }
        }
        return undefined;
    }

    private getMetricsForInstanceType(instanceType: string, inInstances: any[]): MetricDefinition[] {
        let metricsForInstanceType: MetricDefinition[] = [];
        switch (instanceType.toUpperCase()) {
            case "AUTHOR":
                metricsForInstanceType = getAuthorMetrics(inInstances.filter(i => i.type === "publish").map(i => i.name));
                break;
            case "PUBLISH":
                metricsForInstanceType = getPublishMetrics();
                break;
            case "DISPATCHER":
                metricsForInstanceType = getDispatcherMetrics();
                break;
        }
        return metricsForInstanceType;
    }

    private populateMetrics(programId: string, envName: string, instance: any, inInstances: any[]): void {
        const metricsForInstanceType = this.getMetricsForInstanceType(instance.type, inInstances);

        const instanceMetrics = metricsForInstanceType.map(m => {
            const links: any = {};
            links[RELS.instanceGraph] = {
                href: `/api/program/${programId}/environment/${envName}/metric/${m.id}?hostName=${instance.hostName}`,
                templated: false
            };
            return {
                ...m,
                hostName: instance.hostName,
                _links: links
            };
        });
        instance._totalNumberOfItems = instanceMetrics.length;
        instance._embedded = {
            metrics: instanceMetrics
        };
    }

    @httpGet("/program/:programId/environment/:envName/metric/:metricId")
    public getMetricData(@requestParam("programId") programId: string, @requestParam("envName") envName: string, @requestParam("metricId") metricId: string, @queryParam("hostName") hostNames: string | string[]) {
        const time = moment();
        if (!_.isArray(hostNames)) {
            hostNames = [hostNames];
        }
        const program = this.programService.getRawProgram(programId);
        if (program) {
            const env = _.find(program.environments, e => e.name === envName);
            if (env) {
                const result = new ListofMonitoringMetricData();
                const inInstances = this.getRawInstances(env);
                let metricData = hostNames.map(hostName => {
                    const instance = inInstances.find((i: any) => i.hostName === hostName);
                    if (!instance) {
                        return undefined;
                    }
                    const availableMetrics = this.getMetricsForInstanceType(instance.type, inInstances);
                    if (!availableMetrics) {
                        return undefined;
                    }
                    const metricDefinition = availableMetrics.find((md: any) => md.id === metricId);
                    if (!metricDefinition) {
                        return undefined;
                    }
                    if (metricDefinition.subMetrics) {
                        return metricDefinition.subMetrics.map((sub: any) => {
                            const result = new Monitoringmetricdata({
                                name: hostName,
                                metric: metricDefinition.name,
                                legendLabel: sub.label,
                                value: this.generateValues(time, sub.baselineValue, metricDefinition.modifications)
                            });
                            return result;
                        });
                    } else {
                        if (_.isUndefined(metricDefinition.baselineValue)) {
                            return undefined;
                        }
                        const result = new Monitoringmetricdata({
                            "name": hostName,
                            "metric": metricDefinition.name,
                            "legendLabel": metricDefinition.label ? metricDefinition.label : metricDefinition.id,
                            value: this.generateValues(time, metricDefinition.baselineValue, metricDefinition.modifications)
                        });
                        return result;
                    }
                }).filter(d => d).reduce((acc: Monitoringmetricdata[], val: Monitoringmetricdata[]) => acc.concat(val), []);

                if (!_.isArray(metricData)) {
                    metricData = [ metricData ];
                }

                result._embedded = {
                    metricData: metricData
                };
                result._totalNumberOfItems = metricData.length;

                result.addLink(RELS.metrics, `/api/program/${programId}/environment/${envName}/instances/metrics`);
                return result;
            }
        }

        return undefined;
    }

    DURATION_IN_HOURS = 4;
    SAMPLE_RATE = 1;
    DATA_POINTS = this.DURATION_IN_HOURS * 60 / this.SAMPLE_RATE;

    private generateValues(time: moment.Moment, baselineValue: number, modifications: Modification[]): DataPoint[] {
        let value = baselineValue;

        const dataTime = time.clone().subtract(this.DURATION_IN_HOURS, "h").subtract(this.SAMPLE_RATE, "m");
        const result: DataPoint[] = [];
        for (let i = 0; i < this.DATA_POINTS; i++) {
            const modification = modifications && modifications.find(m => m.point == i);
            if (modification) {
                if (modification.type === ModificationType.factor) {
                    value = value * modification.factor;
                }
            }
            result.unshift({
                xPointValue: dataTime.unix(),
                yPointValue: value
            });
            dataTime.add(this.SAMPLE_RATE, "m");
        }
        return result;
    }

    private getRawInstances(env: any): any {
        const inInstances = [{
            "type" : "author",
            "index" : 1,
            "name" : `author1useast1-${env.type}`,
            "hostName" : `${env.name}-author1useast1-${env.type}`
        }];
        for (let i = 1; i <= (env.additionalTiers ? env.additionalTiers + 1 : 1); i++) {
            inInstances.push({
                "type" : "publish",
                "index" : i,
                "name" : `publish${i}useast1-${env.type}`,
                "hostName" : `${env.name}-publish${i}useast1-${env.type}`
            });
            inInstances.push({
                "type" : "dispatcher",
                "index" : i,
                "name" : `dispatcher${i}useast1-${env.type}`,
                "hostName" : `${env.name}-dispatcher${i}useast1-${env.type}`
            });
        }
        return inInstances;
    }

    @httpPut("/program/:programId/environment/:envName/job/scaleUp")
    public scaleUp(@requestParam("programId") programId: string, @requestParam("envName") envName: string, @requestBody() body: any) {
        const program = this.programService.getRawProgram(programId);
        if (program) {
            const additions = body.numberPDTiers;
            const environment = _.find(program.environments, env => env.name == envName);
            if (environment) {
                if (environment.additionalTiers) {
                    environment.additionalTiers = environment.additionalTiers + additions;
                } else {
                    environment.additionalTiers = additions;
                }
                return 201;
            }
        }
        return undefined;
    }

    private getSize(envType: string): number {
        if (envType === "prod") {
            return 150;
        } else {
            return 80;
        }
    }
}

class DataPoint {
    xPointValue: number;
    yPointValue: number;
}