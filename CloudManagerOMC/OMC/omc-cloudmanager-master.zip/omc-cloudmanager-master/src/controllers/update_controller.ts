import { controller, BaseHttpController, httpPost, requestParam, requestBody } from "inversify-express-utils";
import { inject } from "inversify";
import { TYPES } from "../types";
import { ProgramService } from "../services/programs";
import { CiCdPipelineType, Config } from "../services/config";
import _ from "lodash";

@controller("/api")
class Update extends BaseHttpController {
    @inject(TYPES.ProgramService) private programService: ProgramService;
    @inject(TYPES.Config) private config: Config;

    @httpPost("/program/:programId/update/report")
    public generateReport(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program && program.updateState) {
            const modifyStatus = program.updateState.status === "ready";
            program.updateState.report = {};
            if (modifyStatus) {
                program.updateState.status = "generating-report";
            }
            setTimeout(() => {
                program.updateState.report = {
                    url : `http://${this.httpContext.request.hostname}:${this.config.getPort()}/files/update-report.pdf`,
                    date: new Date().getTime()
                };
                if (modifyStatus) {
                    program.updateState.status = "generated-report";
                }
            }, 5000);
        }
        return {};
    }

    @httpPost("/program/:programId/update/branch")
    public createBranch(@requestParam("programId") programId: string, @requestBody() body: any) {
        const program = this.programService.getRawProgram(programId);
        if (program && program.updateState && body.branchName) {
            if (!program.branches) {
                program.branches = [];
            }
            program.updateState.branch = {};
            program.updateState.status = "creating-branch";
            setTimeout(() => {
                const pipelineName = "AEM 6.5 Update Code Quality Pipeline";
                if (!program.nonProductionPipelines) {
                    program.nonProductionPipelines = [];
                }
                program.nonProductionPipelines.push({
                    name: pipelineName,
                    type: CiCdPipelineType.codeQualityOnly,
                    branch: body.branchName,
                    trigger: "manual",
                    importantMetricsFailureBehavior: "PAUSE"
                });

                program.branches.push(body.branchName);
                program.updateState.status = "created-branch";
                program.updateState.branch = {
                    name: body.branchName,
                    date: new Date().getTime()
                };
                let mappedExecution;
                if (program.branchExecutions) {
                    if (program.branchExecutions[body.source]) {
                        mappedExecution = program.branchExecutions[body.source];
                    }
                } else {
                    program.branchExecutions = {};
                }
                if (program.branchExecutionMapping && program.branchExecutionMapping[body.source]) {
                    mappedExecution = program.executions[program.branchExecutionMapping[body.source]];
                }
                mappedExecution = _.cloneDeepWith(mappedExecution);
                mappedExecution.branch = body.branchName;
                program.branchExecutions[body.branchName] = mappedExecution;

                program.updateState.codeQualityPipeline = {
                    id: pipelineName
                };
            }, 5000);
        }

        return {};
    }

    @httpPost("/program/:programId/update/sandbox")
    public createSandbox(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program && program.updateState) {
            program.updateState.status = "creating-sandbox";
            program.updateState.sandbox = {
            };
            setTimeout(() => {
                if (!program.nonProductionPipelines) {
                    program.nonProductionPipelines = [];
                }
                const pipelineName = "AEM 6.5 Update Sandbox Pipeline";
                const envName = `${program.id}-65-sandbox`;
                program.nonProductionPipelines.push({
                    name: pipelineName,
                    type: CiCdPipelineType.nonProductionDeploy,
                    branch: program.updateState.branch.name,
                    trigger: "manual",
                    importantMetricsFailureBehavior: "PAUSE",
                    environmentId: envName
                });
                program.environments.push({
                    "name" : envName,
                    "type" : "dev",
                    "status" : "running"
                });
                program.updateState.sandboxPipeline = {
                    id: pipelineName
                };
                program.updateState.sandbox = {
                    name: envName,
                    date: new Date().getTime()
                };
                program.updateState.status = "created-sandbox";
            }, 10000);
        }
        return {};
    }

    @httpPost("/program/:programId/update/stage")
    public createStage(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program && program.updateState) {
            program.updateState.status = "creating-stage";
            program.updateState.stage = {
            };
            setTimeout(() => {
                const originalStage = _.find(program.environments, env => env.type === "stage");
                const envName = `${program.id}-65-stage`;
                program.environments.push({
                    "name" : envName,
                    "type" : "stage",
                    "status" : "running",
                    "urls": {
                        "author": "http://localhost:4502/", // originalStage.urls.author.replace("stage", "65-stage"),
                        "publish": "http://localhost:4503/", // originalStage.urls.author.replace("stage", "65-stage")
                    }
                });
                program.updateState.stage = {
                    name: envName,
                    date: new Date().getTime()
                };
                program.updateState.status = "created-stage";
            }, 15000);
        }
        return {};
    }

    @httpPost("/program/:programId/update/prod")
    public createProd(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program && program.updateState) {
            program.updateState.status = "creating-prod";
            program.updateState.prod = {
            };
            setTimeout(() => {
                const envName = `${program.id}-65-prod`;
                program.environments.push({
                    "name" : envName,
                    "type" : "prod",
                    "status" : "running"
                });
                program.updateState.prod = {
                    name: envName,
                    date: new Date().getTime()
                };
                program.updateState.status = "created-prod";

                const validationPipeline = _.cloneDeep(program.pipeline);
                validationPipeline.branch = program.updateState.branch.name;
                validationPipeline.stageEnvironmentId = program.updateState.stage.name;
                validationPipeline.prodEnvironmentId = program.updateState.prod.name;
                validationPipeline.cseoversight = false;
                program.updateState.validationPipeline = {
                    id: this.config.getValidatePipelineName()
                };
                program.validationPipeline = validationPipeline;

            }, 15000);
        }
        return {};
    }

    @httpPost("/program/:programId/update/golive")
    public goLive(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program && program.updateState) {
            program.updateState.status = "preparing-for-cutover";
            setTimeout(() => {
                program.updateState.status = "ready-for-cutover";
            }, 15000);
        }
        return {};
    }

    @httpPost("/program/:programId/update/happy")
    public happy(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program && program.updateState) {
            program.updateState.status = "becoming-happy";
            setTimeout(() => {
                program.updateState.status = "happy";
            }, 5000);
        }
        return {};
    }
}