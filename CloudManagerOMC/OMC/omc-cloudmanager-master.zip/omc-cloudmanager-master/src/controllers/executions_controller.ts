import { controller, BaseHttpController, httpGet, requestParam, queryParam, httpPut } from "inversify-express-utils";
import { PipelineExecutionListRepresentation, PipelineExecution, pipeline_trigger, pipeline_type, PipelineExecutionStepState, pipelineExecutionStepState_status, Metric, ArtifactList, Artifact, pipelineExecution_status, pipelinePhase_type, pipelineExecution_trigger, pipelineExecution_pipelineType } from "../models";
import { Request, Response } from "express";
import { RELS } from "../rels";
import { TYPES } from "../types";
import { inject } from "inversify";
import { ProgramService } from "../services/programs";
import { Config, StepType, StepPhase, CiCdPipelineType, toStepType } from "../services/config";
import * as _ from "lodash";
const Dates = require("date-math");
import rawMetrics from "../data/metrics.json";
import url from "url";
import { PipelineService } from "../services/pipeline";
import { ceil, priorStepFailed, setMetricResult, isRunning, isPriorStepRunning } from "../helpers/pipeline-helper";
import { isCloud } from "../helpers/program-helper";

@controller("/api")
class ExecutionsController extends BaseHttpController {

    @inject(TYPES.ProgramService) private programService: ProgramService;
    @inject(TYPES.PipelineService) private pipelineService: PipelineService;
    @inject(TYPES.Config) private config: Config;

    @httpGet("/program/:programId/executions")
    public getAllExecutions(@requestParam("programId") programId: string, @queryParam("start") startParam: string,
                            @queryParam("limit") limitParam: string, @queryParam("property") property: string, req: Request) {
        return this.getExecutions(programId, "ALL", startParam, limitParam, property, req);
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/executions")
    public getExecutions(@requestParam("programId") programId: string, @requestParam("pipelineId") pipelineId: string, @queryParam("start") startParam: string,
                            @queryParam("limit") limitParam: string, @queryParam("property") property: string, req: Request) {
        const program = this.programService.getRawProgram(programId);

        let start: number;
        if (!startParam) {
            start = 0;
        } else {
            start = parseInt(startParam, 10);
        }
        let limit: number;
        if (!limitParam) {
            limit = 20;
        } else {
            limit = parseInt(limitParam, 10);
        }

        const result = new PipelineExecutionListRepresentation();
        result._page.limit = limit;
        result._page.prev = ceil(start - limit, 0);
        result._page.next = start + limit;

        let filteredExecutions: any[] = _.map(program.executions);
        if (pipelineId !== "ALL") {
            filteredExecutions = _.filter(filteredExecutions, e => e.pipelineId === pipelineId);
        }
        filteredExecutions = _.reverse(_.sortBy(filteredExecutions, (exec) => {
            return parseInt(exec.id, 10);
        }));

        let propertyParam: string;
        if (property) {
            result._page.property.push(property);
            propertyParam = `&property=${propertyParam}`;
            const parts = property.split("==");
            filteredExecutions = _.filter(filteredExecutions, (execution) => {
                return execution[parts[0]] == parts[1];
            });
        } else {
            propertyParam = "";
        }

        if (filteredExecutions) {
            filteredExecutions = _.slice(filteredExecutions, start, limit);
        }

        const mappedExecutions = _.map(filteredExecutions, (execution) => {
            switch (execution.pipelineType) {
                case pipelineExecution_pipelineType.CODE_GENERATOR:
                    return this.populateCodeGeneratorExecution(program, execution);
                default:
                    return this.populateCiCdExecution(program, execution);
            }
        });

        result._embedded = {
            executions: mappedExecutions
        };
        result._totalNumberOfItems = mappedExecutions.length;

        result.addSelf(req.url);
        const basePath = (pipelineId == "ALL") ? `/api/program/${programId}` : `/api/program/${programId}/pipeline/${pipelineId}`;
        result.addLink(RELS.next, `${basePath}/executions?start=${result._page.next}&limit=${limit}${propertyParam}`);
        result.addLink(RELS.prev, `${basePath}/executions?start=${result._page.prev}&limit=${limit}${propertyParam}`);
        result.addLink(RELS.page, `${basePath}/executions?start={start}&limit={limit}&property={property}`, true);

        return result;
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution")
    public getCurrentExecution(@requestParam("programId") programId: string, @requestParam("pipelineId") pipelineId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program.activeExecutionId && program.activeExecutionId.pipelineId) {
            return this.getExecution(programId, program.activeExecutionId.pipelineId);
        } else {
            return 404;
        }
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId")
    public getExecution(@requestParam("programId") programId: string, @requestParam("executionId") executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        if (!execution) {
            return 404;
        }
        return this.populateCiCdExecution(program, execution);
    }

    @httpPut("/program/:programId/pipeline/:pipelineId/execution")
    public startExecution(@requestParam("programId") programId: string, @requestParam("pipelineId") pipelineId: string) {
        const newExecutionId = this.pipelineService.startCiCdExecution(programId, pipelineId);
        this.httpContext.response.status(201).send(this.getExecution(programId, newExecutionId));
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/stageDeploy/step/securityTest/metrics")
    public getSecurityTestMetrics(@requestParam("programId") programId: string, @requestParam("executionId") executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        const futureSteps = [ StepType.reportPerformanceTest, StepType.prodDeploy ];

        const resultingMetrics = _.map(rawMetrics.securityTest, (metric) => {
            return new Metric(metric);
        });

        setMetricResult(resultingMetrics, "replication_and_transport_users", "false", false, false);
        setMetricResult(resultingMetrics, "deserialization_firewall_attach_api_readiness", "true", true, false);
        setMetricResult(resultingMetrics, "ssl_configuration", "true", true, false);
        setMetricResult(resultingMetrics, "sling_get_servlet", "true", true, false);
        setMetricResult(resultingMetrics, "davex_health_check", "true", true, false);
        setMetricResult(resultingMetrics, "deserialization_firewall_loaded", "true", true, false);
        setMetricResult(resultingMetrics, "cq_html_library_manager_config", "true", true, false);
        setMetricResult(resultingMetrics, "sling_java_script_handler", "true", true, false);
        setMetricResult(resultingMetrics, "deserialization_firewall_functional", "true", true, false);
        setMetricResult(resultingMetrics, "sling_referrer_filter", "true", true, false);
        setMetricResult(resultingMetrics, "example_content_packages", "false", false, false);
        setMetricResult(resultingMetrics, "default_login_accounts", "true", true, false);
        setMetricResult(resultingMetrics, "web_server_configuration", "true", true, false);
        setMetricResult(resultingMetrics, "cq_dispatcher_configuration", "true", true, false);
        setMetricResult(resultingMetrics, "sling_jsp_script_handler", "true", true, false);
        setMetricResult(resultingMetrics, "webdav_health_check", "true", true, false);
        setMetricResult(resultingMetrics, "crxde_support", "true", true, false);
        setMetricResult(resultingMetrics, "user_profile_default_access", "true", true, false);
        setMetricResult(resultingMetrics, "authorizable_node_name_generation", "true", true, false);
        setMetricResult(resultingMetrics, "wcm_filter_configuration", "true", true, false);

        if (execution.status == "FAILED" && execution.failureStep == StepType.securityTest) {
            setMetricResult(resultingMetrics, "cq_dispatcher_configuration", "false", false, false);
        } else if (!isRunning(execution) || execution.waitingStep == StepType.securityTest || futureSteps.indexOf(execution.runningStep) >= -1) {
            setMetricResult(resultingMetrics, "davex_health_check", "false", false, execution.waitingStep == StepType.securityTest ? false : true);
        }

        return {
            "metrics": resultingMetrics
        };
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/stageDeploy/step/securityTest/artifacts")
    public getSecurityTestArtifacts(@requestParam("programId") programId: string,
                                   @requestParam("pipelineId") pipelineId: string,
                                   @requestParam("executionId") executionId: string) {
        const result = new ArtifactList();
        result._totalNumberOfItems = 0;
        result._embedded = {
            artifacts: []
        };
        result.addSelf(`/api/program/${programId}/pipeline/${pipelineId}/execution/${executionId}/phase/stageDeploy/step/securityTest/artifacts`);

        return result;
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/stageDeploy/step/reportPerformanceTest/metrics")
    public getPerformanceTestMetrics(@requestParam("programId") programId: string, @requestParam("executionId") executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        const futureSteps = [ StepType.prodDeploy ];

        const resultingMetrics = _.map(rawMetrics.loadTest, (metric) => {
            const rawData = _.clone(metric);
            _.each(program.kpis, function(kpiValue, kpiKey) {
                rawData.expectedValue = _.replace(rawData.expectedValue, `{${kpiKey}}`, kpiValue);
            });
            return new Metric(rawData);
        });

        setMetricResult(resultingMetrics, "disk_bandwidth_util", "3.9", true, false);
        setMetricResult(resultingMetrics, "requests_per_minute", "1444.37", true, false);
        setMetricResult(resultingMetrics, "cpu_utilization_rate", "17.67", true, false);
        setMetricResult(resultingMetrics, "network_bandwidth_util", "5.7", true, false);
        setMetricResult(resultingMetrics, "disk_io_wait_time", "10.2", true, false);

        if (program.solutions.indexOf("aemsites") >= 0) {
            const avgResponseTimeInSec = (program.kpis.avgResponseTimeInSec * 0.78325).toFixed(2).toString();
            const avgVisitorsPerMin = (program.kpis.avgVisitorsPerMin * 1.03).toFixed(2).toString();

            setMetricResult(resultingMetrics, "views_per_minute", avgVisitorsPerMin, true, false);
            setMetricResult(resultingMetrics, "error_rate", "0.39", true, false);
            setMetricResult(resultingMetrics, "response_time", avgResponseTimeInSec, true, false);
            setMetricResult(resultingMetrics, "peak_resp_time", "14.7", true, false); // 27.23
        }

        if (program.solutions.indexOf("aemassets") >= 0) {
            const assetsProcessingTime = (program.kpis.assetsProcessingTime * 0.78325).toFixed(2).toString();
            const assetsUploadPerMinute = (program.kpis.assetsUploadPerMinute * 1.07).toFixed(2).toString();

            setMetricResult(resultingMetrics, "uploads_per_minute", assetsUploadPerMinute, true, false);
            setMetricResult(resultingMetrics, "processing_time", assetsProcessingTime, true, false);
        }

        if (execution.status == "FAILED" && execution.failureStep == StepType.reportPerformanceTest) {
            setMetricResult(resultingMetrics, "cpu_utilization_rate", "90", false, false);
        } else if (execution.stepsRequiringOverride.indexOf(StepType.reportPerformanceTest) >= 0 &&
                    (!isRunning(execution) || execution.waitingStep == StepType.reportPerformanceTest || futureSteps.indexOf(execution.runningStep) >= -1)) {
            setMetricResult(resultingMetrics, "network_bandwidth_util", "95", false, execution.waitingStep == StepType.reportPerformanceTest ? false : true);
        }

        return {
            "metrics": _.filter(resultingMetrics, (metric) => {
                return !_.isUndefined(metric.actualValue);
            })
        };
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/stageDeploy/step/reportPerformanceTest/artifacts")
    public getPerformanceTestArtifacts(@requestParam("programId") programId: string,
                                   @requestParam("pipelineId") pipelineId: string,
                                   @requestParam("executionId") executionId: string) {
        const result = new ArtifactList();
        const embedded: Artifact[] = [];
        const url = this.httpContext.request.url;
        const baseUrl = url.substring(0, url.length - 1);

        embedded.push(this.createArtifact({
            file: "errorGraph.json",
            format: "application/json",
            id: "errorGraph.json",
            md5: "",
            stepName: StepType.reportPerformanceTest,
            type: "LOAD_ERROR_GRAPH_JSON"
        }, baseUrl));
        embedded.push(this.createArtifact({
            file: "peakResponseTimeGraph.json",
            format: "application/json",
            id: "peakResponseTimeGraph.json",
            md5: "",
            stepName: StepType.reportPerformanceTest,
            type: "LOAD_PEAK_RESPONSE_TIME_GRAPH_JSON"
        }, baseUrl));
        embedded.push(this.createArtifact({
            file: "cpuIOWaitPercent.json",
            format: "application/json",
            id: "cpuIOWaitPercent.json",
            md5: "",
            stepName: StepType.reportPerformanceTest,
            type: "CPU_I_O_WAIT_PERCENT_JSON"
        }, baseUrl));
        embedded.push(this.createArtifact({
            file: "errorPages.csv",
            format: "text/csv",
            id: "errorPages.csv",
            md5: "",
            stepName: StepType.reportPerformanceTest,
            type: "LOAD_ERROR_PAGES"
        }, baseUrl));
        embedded.push(this.createArtifact({
            file: "cpuPercent.json",
            format: "application/json",
            id: "cpuPercent.json",
            md5: "",
            stepName: StepType.reportPerformanceTest,
            type: "CPU_PERCENT_JSON"
        }, baseUrl));
        embedded.push(this.createArtifact({
            file: "diskUtilizationPercent.json",
            format: "application/json",
            id: "diskUtilizationPercent.json",
            md5: "",
            stepName: StepType.reportPerformanceTest,
            type: "DISK_UTILIZATION_PERCENT_JSON"
        }, baseUrl));
        embedded.push(this.createArtifact({
            file: "responseTimeGraph.json",
            format: "application/json",
            id: "responseTimeGraph.json",
            md5: "",
            stepName: StepType.reportPerformanceTest,
            type: "LOAD_RESPONSE_TIME_GRAPH_JSON"
        }, baseUrl));
        embedded.push(this.createArtifact({
            file: "slowPages.csv",
            format: "text/csv",
            id: "slowPages.csv",
            md5: "",
            stepName: StepType.reportPerformanceTest,
            type: "LOAD_SLOW_PAGES"
        }, baseUrl));
        embedded.push(this.createArtifact({
            file: "networkBandwidthGraph.json",
            format: "application/json",
            id: "networkBandwidthGraph.json",
            md5: "",
            stepName: StepType.reportPerformanceTest,
            type: "NETWORK_BANDWIDTH_JSON"
        }, baseUrl));

        result._totalNumberOfItems = embedded.length;
        result._embedded = {
            artifacts: embedded
        };
        result.addSelf(this.httpContext.request.url);

        return result;
    }

    private createArtifact(options: any, baseHref: string): Artifact {
        const result = new Artifact(options);
        result.addSelf(`${baseHref}/${options.id}`);
        return result;
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/stageDeploy/step/reportPerformanceTest/artifact/:artifactId")
    public getPerformanceTestArtifact(@requestParam("programId") programId: string,
                                   @requestParam("pipelineId") pipelineId: string,
                                   @requestParam("executionId") executionId: string,
                                   @requestParam("artifactId") artifactId: string) {
        return {
            "redirect" : `http://${this.httpContext.request.hostname}:${this.config.getPort()}/performanceData/${artifactId}`
        };
    }


    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/build/step/codeQuality/metrics")
    public getCodeQualityMetrics(@requestParam("programId") programId: string, @requestParam("executionId") executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];
        const futureSteps = [ StepType.stageDeploy, StepType.securityTest, StepType.reportPerformanceTest, StepType.prodDeploy ];

        const resultingMetrics = _.map(rawMetrics.codeQuality, (metric) => {
            return new Metric(metric);
        });

        if (execution.status == pipelineExecution_status.FAILED && execution.failureStep == StepType.codeQuality) {
            setMetricResult(resultingMetrics, "skipped_tests", "0", true, false);
            setMetricResult(resultingMetrics, "duplicated_lines_density", "0.2", true, false);
            setMetricResult(resultingMetrics, "reliability_rating", "B", true, false);
            setMetricResult(resultingMetrics, "coverage", "45", false, false);
            setMetricResult(resultingMetrics, "security_rating_imp", "B", true, false);
            setMetricResult(resultingMetrics, "security_rating", "B", false, false);
            setMetricResult(resultingMetrics, "open_issues", "142", false, false);
            setMetricResult(resultingMetrics, "sqale_rating", "A", true, false);
        } else if (execution.status == "FINISHED" || execution.waitingStep == "codeQuality" || futureSteps.indexOf(execution.runningStep) >= -1) {
            setMetricResult(resultingMetrics, "skipped_tests", "0", true, false);
            setMetricResult(resultingMetrics, "duplicated_lines_density", "0.2", true, false);
            setMetricResult(resultingMetrics, "reliability_rating", "B", true, false);
            setMetricResult(resultingMetrics, "coverage", "45", false, execution.waitingStep == "codeQuality" ? false : true);
            setMetricResult(resultingMetrics, "security_rating_imp", "A", true, false);
            setMetricResult(resultingMetrics, "security_rating", "A", true, false);
            setMetricResult(resultingMetrics, "open_issues", "142", false, false);
            setMetricResult(resultingMetrics, "sqale_rating", "A", true, false);
        }

        return {
            "metrics": resultingMetrics
        };
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/build/step/codeQuality/artifacts")
    public getCodeQualityArtifacts(@requestParam("programId") programId: string,
                                   @requestParam("pipelineId") pipelineId: string,
                                   @requestParam("executionId") executionId: string) {
        const result = new ArtifactList();
        result._totalNumberOfItems = 0;
        result._embedded = {
            artifacts: []
        };
        result.addSelf(`/api/program/${programId}/pipeline/${pipelineId}/execution/${executionId}/phase/build/step/codeQuality/artifacts`);

        return result;
    }

    @httpPut("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/build/step/codeQuality/advance")
    public overrideCodeQuality(@requestParam("programId") programId: string, @requestParam("executionId") executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];

        this.pipelineService.overrideCodeQuality(programId, executionId);

        return 202;
    }

    @httpPut("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/stageDeploy/step/securityTest/advance")
    public overrideSecurityTest(@requestParam("programId") programId: string, @requestParam("executionId") executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];

        this.pipelineService.overrideSecurityTest(programId, executionId);

        return 202;
    }

    @httpPut("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/stageDeploy/step/securityTest/advance")
    public overridePerformanceTest(@requestParam("programId") programId: string, @requestParam("executionId") executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];

        this.pipelineService.overridePerformanceTest(programId, executionId);

        return 202;
    }

    @httpPut("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/prodDeploy/step/approval/advance")
    public approve(@requestParam("programId") programId: string, @requestParam("executionId") executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];

        this.pipelineService.approve(programId, executionId);

        return 202;
    }

    @httpPut("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/prodDeploy/step/schedule/advance")
    public schedule(@requestParam("programId") programId: string, @requestParam("executionId") executionId: string) {
        const program = this.programService.getRawProgram(programId);
        const execution = program.executions[executionId];

        this.pipelineService.schedule(programId, executionId);

        return 202;
    }

    private populateCodeGeneratorExecution(program: any, rawExecution: any): PipelineExecution {
        const result = new PipelineExecution();
        result.id = rawExecution.id;
        result.programId = program.id;

        result.trigger = pipelineExecution_trigger.MANUAL;
        result.user = rawExecution.user;
        result.status = rawExecution.status;
        result.createdAt = rawExecution.createdAt;
        result.updatedAt = rawExecution.updatedAt;
        result.pipelineType = pipelineExecution_pipelineType.CODE_GENERATOR;

        const stepStates: PipelineExecutionStepState[] = [];
        this.createCodeGeneratorBuildStepState(stepStates, program, rawExecution);

        result.stepStates = stepStates;
        result._embedded = {
            stepStates: stepStates
        };

        result.addLink(RELS.program, `/api/program/${program.id}`);

        return result;
    }

    private populateCiCdExecution(program: any, rawExecution: any): PipelineExecution {
        const result = new PipelineExecution();
        const pipeline = this.pipelineService.findPipeline(program.id, rawExecution.pipelineId);

        result.id = rawExecution.id;
        result.programId = program.id;
        result.pipelineId = rawExecution.pipelineId;
        if (pipeline.type === CiCdPipelineType.production) {
            result.artifactsVersion = rawExecution.version;
        }
        result.trigger = pipelineExecution_trigger.MANUAL;
        result.user = rawExecution.user;
        result.status = rawExecution.status;
        result.createdAt = rawExecution.createdAt;
        result.updatedAt = rawExecution.updatedAt;
        result.pipelineType = pipelineExecution_pipelineType.CI_CD;

        const stepStates: PipelineExecutionStepState[] = [];

        this.createValidateStepState(stepStates, program, rawExecution);
        this.createBuildStepState(stepStates, program, rawExecution);
        this.createCodeQualityStepState(stepStates, program, rawExecution);
        if (isCloud(program)) {
            this.createBuildImageStepState(stepStates, program, rawExecution);
        }
        if (pipeline.type === CiCdPipelineType.production) {
            this.createStageDeployStepState(stepStates, program, pipeline.stageEnvironmentId, rawExecution);
            this.createSecurityTestStepState(stepStates, program, pipeline.stageEnvironmentId, rawExecution);
            this.createPerformanceTestStepState(stepStates, program, pipeline.stageEnvironmentId, rawExecution);
            if (rawExecution.options && rawExecution.options.approval) {
                this.createApprovalStepState(stepStates, program, pipeline.prodEnvironmentId, rawExecution);
            }
            if (rawExecution.options && rawExecution.options.scheduled) {
                this.createScheduledStepState(stepStates, program, pipeline.prodEnvironmentId, rawExecution);
            }
            if (rawExecution.options && rawExecution.options.managed) {
                this.createManagedStepState(stepStates, program, pipeline.prodEnvironmentId, rawExecution);
            }

            this.createProductionDeployStepState(stepStates, program, pipeline.prodEnvironmentId, rawExecution);
        } else if (pipeline.type === CiCdPipelineType.nonProductionDeploy) {
            this.createDevDeployStepState(stepStates, program, pipeline.environmentId, rawExecution);
        }

        // result.finishedAt = rawExecution.finishedAt;
        const lastFinishedStep = _.last(_.filter(stepStates, (stepState) => {
            return stepState.status == pipelineExecutionStepState_status.FAILED || stepState.status == pipelineExecutionStepState_status.FINISHED || stepState.status == pipelineExecutionStepState_status.CANCELLED;
        }));
        if (lastFinishedStep) {
            result.finishedAt = lastFinishedStep.finishedAt;
        }

        result.stepStates = stepStates;
        result._embedded = {
            stepStates: stepStates
        };

        result.addLink(RELS.pipeline, `/api/program/${program.id}/pipeline/${result.pipelineId}`);
        result.addLink(RELS.pipelineAdvance, `/api/program/${program.id}/pipeline/${result.pipelineId}/execution/${rawExecution.id}/phase/{phaseId}/step/{stepId}/advance`, true);
        result.addLink(RELS.artifacts, `/api/program/${program.id}/pipeline/${result.pipelineId}/execution/${rawExecution.id}/phase/{phaseId}/step/{stepId}/artifacts`, true);
        result.addLink(RELS.pipelineCancel, `/api/program/${program.id}/pipeline/${result.pipelineId}/execution/${rawExecution.id}/phase/{phaseId}/step/{stepId}/cancel`, true);
        result.addLink(RELS.logs, `/api/program/${program.id}/pipeline/${result.pipelineId}/execution/${rawExecution.id}/phase/{phaseId}/step/{stepId}/logs`, true);
        result.addLink(RELS.metrics, `/api/program/${program.id}/pipeline/${result.pipelineId}/execution/${rawExecution.id}/phase/{phaseId}/step/{stepId}/metrics`, true);
        result.addLink(RELS.program, `/api/program/${program.id}`);
        result.addSelf(`/api/program/${program.id}/pipeline/${result.pipelineId}/execution/${rawExecution.id}`);

        return result;
    }

    private updateStartAndFinish(stepState: PipelineExecutionStepState, stepType: StepType, pipelineStart: Date, priorSteps: PipelineExecutionStepState[]) {
        this.updateStart(stepState, stepType, pipelineStart, priorSteps);
        stepState.finishedAt = Dates.second.shift(stepState.startedAt, this.config.getDuration(stepType));
    }
    private updateStart(stepState: PipelineExecutionStepState, stepType: StepType, pipelineStart: Date, priorSteps: PipelineExecutionStepState[]) {
        stepState.startedAt = pipelineStart;
        _.each(priorSteps, (priorStepState) => {
            const priorStepType: StepType = toStepType(priorStepState.id);
            stepState.startedAt = Dates.second.shift(stepState.startedAt, this.config.getDuration(priorStepType));
        });
    }

    private createValidateStepState(stepStates: PipelineExecutionStepState[], program: any, rawExecution: any): void {
        const start = new Date(rawExecution.createdAt);
        const result = new PipelineExecutionStepState({
            id: StepType.validate,
            stepId: StepType.validate,
            phaseId: StepPhase.build,
            executionId: rawExecution.id,
            pipelineId: rawExecution.pipelineId,
            programId: program.id,
            action: StepType.validate,
            startedAt: start
        });
        if (!isRunning(rawExecution)) {
            this.updateStartAndFinish(result, StepType.validate, start, []);
            result.status = pipelineExecutionStepState_status.FINISHED;
        } else if (rawExecution.runningStep == StepType.validate) {
            this.updateStart(result, StepType.validate, start, []);
            result.status = pipelineExecutionStepState_status.RUNNING;
        } else {
            this.updateStartAndFinish(result, StepType.validate, start, []);
            result.status = pipelineExecutionStepState_status.FINISHED;
        }

        stepStates.push(result);
    }

    private createBuildStepState(stepStates: PipelineExecutionStepState[], program: any, rawExecution: any): void {
        const start = new Date(rawExecution.createdAt);
        const result = new PipelineExecutionStepState({
            id: StepType.build,
            stepId: StepType.build,
            phaseId: StepPhase.build,
            executionId: rawExecution.id,
            pipelineId: rawExecution.pipelineId,
            programId: program.id,
            action: StepType.build,
            repository: program.id,
            branch: rawExecution.branch
        });
        if (!isRunning(rawExecution)) {
            this.updateStartAndFinish(result, StepType.build, start, stepStates);
            result.status = pipelineExecutionStepState_status.FINISHED;
        } else if (rawExecution.runningStep == result.id) {
            this.updateStart(result, StepType.build, start, stepStates);
            result.status = pipelineExecutionStepState_status.RUNNING;
        } else if (isPriorStepRunning(rawExecution, stepStates)) {
            result.status = pipelineExecutionStepState_status.NOT_STARTED;
        } else {
            result.status = pipelineExecutionStepState_status.FINISHED;
        }

        stepStates.push(result);
    }

    private createBuildImageStepState(stepStates: PipelineExecutionStepState[], program: any, rawExecution: any): void {
        const start = new Date(rawExecution.createdAt);
        const result = new PipelineExecutionStepState({
            id: StepType.buildImage,
            stepId: StepType.buildImage,
            phaseId: StepPhase.build,
            executionId: rawExecution.id,
            pipelineId: rawExecution.pipelineId,
            programId: program.id,
            action: StepType.buildImage,
            repository: program.id,
            branch: rawExecution.branch
        });
        if (priorStepFailed(stepStates)) {
            result.status = pipelineExecutionStepState_status.NOT_STARTED;
        } else {
            if (!isRunning(rawExecution)) {
                this.updateStartAndFinish(result, StepType.buildImage, start, stepStates);
                result.status = pipelineExecutionStepState_status.FINISHED;
            } else if (rawExecution.runningStep == result.id) {
                this.updateStart(result, StepType.buildImage, start, stepStates);
                result.status = pipelineExecutionStepState_status.RUNNING;
            } else if (isPriorStepRunning(rawExecution, stepStates)) {
                result.status = pipelineExecutionStepState_status.NOT_STARTED;
            } else {
                result.status = pipelineExecutionStepState_status.FINISHED;
            }
        }

        stepStates.push(result);
    }

    private createCodeGeneratorBuildStepState(stepStates: PipelineExecutionStepState[], program: any, rawExecution: any): void {
        const start = new Date(rawExecution.createdAt);
        const result = new PipelineExecutionStepState({
            id: StepType.build,
            stepId: StepType.build,
            phaseId: StepPhase.build,
            executionId: rawExecution.id,
            programId: program.id,
            action: StepType.build,
            repository: program.id,
            branch: rawExecution.branch,
            details: {
                input: rawExecution.input
            },
            startedAt: start
        });

        if (!isRunning(rawExecution)) {
            result.finishedAt = new Date(rawExecution.finishedAt);
            result.status = pipelineExecutionStepState_status.FINISHED;
        } else {
            result.status = pipelineExecutionStepState_status.RUNNING;
        }

        stepStates.push(result);
    }

    private createProdDeployOptionStep(stepStates: PipelineExecutionStepState[], program: any, environmentId: string, rawExecution: any, stepType: StepType, details: any): void {
        const start = new Date(rawExecution.createdAt);
        const result = new PipelineExecutionStepState({
            id: stepType.toString(),
            stepId: stepType.toString(),
            phaseId: StepPhase.prodDeploy,
            executionId: rawExecution.id,
            pipelineId: rawExecution.pipelineId,
            programId: program.id,
            action: stepType.toString(),
            environmentType: "prod",
            environment: environmentId
        });
        if (priorStepFailed(stepStates)) {
            result.status = pipelineExecutionStepState_status.NOT_STARTED;
        } else {
            if (!isRunning(rawExecution)) {
                this.updateStartAndFinish(result, StepType.schedule, start, stepStates);
                if (rawExecution.status == "FINISHED" || rawExecution.failureStep != result.id) {
                    result.status = rawExecution.status;
                    result.details = details;
                } else {
                    result.status = pipelineExecutionStepState_status.FAILED;
                }
            } else if (rawExecution.waitingStep == result.id) {
                this.updateStart(result, StepType.schedule, start, stepStates);
                result.status = pipelineExecutionStepState_status.WAITING;
            } else if (rawExecution.runningStep == result.id) {
                this.updateStart(result, StepType.schedule, start, stepStates);
                result.status = pipelineExecutionStepState_status.RUNNING;
            } else if (isPriorStepRunning(rawExecution, stepStates)) {
                result.status = pipelineExecutionStepState_status.NOT_STARTED;
            } else {
                result.status = pipelineExecutionStepState_status.FINISHED;
            }
        }

        stepStates.push(result);
    }

    private createApprovalStepState(stepStates: PipelineExecutionStepState[], program: any, environmentId: string, rawExecution: any): void {
        this.createProdDeployOptionStep(stepStates, program, environmentId, rawExecution, StepType.approval, {
            input: {
                override: true
            }
        });
    }

    private createScheduledStepState(stepStates: PipelineExecutionStepState[], program: any, environmentId: string, rawExecution: any): void {
        const priorSteps = [ StepType.validate, StepType.build, StepType.codeQuality, StepType.stageDeploy, StepType.securityTest, StepType.reportPerformanceTest, StepType.approval ];
        this.createProdDeployOptionStep(stepStates, program, environmentId, rawExecution, StepType.schedule, {
            input: {
                type: "IMMEDIATE"
            }
        });
    }

    private createManagedStepState(stepStates: PipelineExecutionStepState[], program: any, environmentId: string, rawExecution: any): void {
        const priorSteps = [ StepType.validate, StepType.build, StepType.codeQuality, StepType.stageDeploy, StepType.securityTest, StepType.reportPerformanceTest, StepType.approval, StepType.schedule ];
        this.createProdDeployOptionStep(stepStates, program, environmentId, rawExecution, StepType.managed, {
            input: {
                override: true
            }
        });
    }

    private createTestStep(stepType: StepType, phase: string, stepStates: PipelineExecutionStepState[],
                           program: any, rawExecution: any, options?: any) {
        const start = new Date(rawExecution.createdAt);
        const result = new PipelineExecutionStepState({
            id: stepType,
            stepId: stepType,
            phaseId: phase,
            executionId: rawExecution.id,
            pipelineId: rawExecution.pipelineId,
            programId: program.id,
            action: stepType,
            repository: program.id,
            branch: rawExecution.branch
        });
        if (options) {
            _.assign(result, options);
        }
        if (priorStepFailed(stepStates)) {
            result.status = pipelineExecutionStepState_status.NOT_STARTED;
        } else {
            if (!isRunning(rawExecution)) {
                this.updateStartAndFinish(result, stepType, start, stepStates);
                if (rawExecution.status == pipelineExecution_status.FINISHED || rawExecution.failureStep != result.id) {
                    result.status = rawExecution.failureStep != result.id ? pipelineExecution_status.FINISHED : rawExecution.status;
                    if (rawExecution.overriddenSteps && rawExecution.overriddenSteps.indexOf(result.id) >= 0) {
                        result.details = {
                            input: {
                                override: true
                            }
                        };
                    }
                } else if (rawExecution.status == pipelineExecution_status.CANCELLED) {
                    result.status = pipelineExecutionStepState_status.CANCELLED;
                } else {
                    result.status = pipelineExecutionStepState_status.FAILED;
                }
            } else if (rawExecution.waitingStep == result.id) {
                this.updateStart(result, stepType, start, stepStates);
                result.status = pipelineExecutionStepState_status.WAITING;
            } else if (rawExecution.runningStep == result.id) {
                this.updateStart(result, stepType, start, stepStates);
                result.status = pipelineExecutionStepState_status.RUNNING;
            } else if (isPriorStepRunning(rawExecution, stepStates)) {
                result.status = pipelineExecutionStepState_status.NOT_STARTED;
            } else {
                result.status = pipelineExecutionStepState_status.FINISHED;
                if (rawExecution.overriddenSteps && rawExecution.overriddenSteps.indexOf(result.id) >= 0) {
                    result.details = {
                        input: {
                            override: true
                        }
                    };
                }
            }
        }

        stepStates.push(result);
    }

    private createCodeQualityStepState(stepStates: PipelineExecutionStepState[], program: any, rawExecution: any): void {
        this.createTestStep(StepType.codeQuality, StepPhase.build, stepStates, program, rawExecution);
    }

    private createSecurityTestStepState(stepStates: PipelineExecutionStepState[], program: any, environmentId: string, rawExecution: any): void {
        this.createTestStep(StepType.securityTest, StepPhase.stageDeploy, stepStates, program, rawExecution, {
            environmentType: "stage",
            environment: environmentId
        });
    }

    private createPerformanceTestStepState(stepStates: PipelineExecutionStepState[], program: any, environmentId: string, rawExecution: any): void {
        this.createTestStep(StepType.reportPerformanceTest, StepPhase.stageDeploy, stepStates, program, rawExecution, {
            environmentType: "stage",
            environment: environmentId
        });
    }

    private createDevDeployStepState(stepStates: PipelineExecutionStepState[], program: any, environmentId: string, rawExecution: any): void {
        const start = new Date(rawExecution.createdAt);
        const result = new PipelineExecutionStepState({
            id: StepType.devDeploy,
            stepId: StepType.devDeploy,
            phaseId: StepPhase.devDeploy,
            executionId: rawExecution.id,
            pipelineId: rawExecution.pipelineId,
            programId: program.id,
            action: "deploy",
            environmentType: "dev",
            environment: environmentId,
            details: {}

        });
        if (priorStepFailed(stepStates)) {
            result.status = pipelineExecutionStepState_status.NOT_STARTED;
        } else {
            if (rawExecution.status == "FINISHED" || rawExecution.status == "FAILED") {
                this.updateStartAndFinish(result, StepType.stageDeploy, start, stepStates);
                if (rawExecution.status == "FINISHED" || rawExecution.failureStep != "stageDeploy") {
                    result.status = rawExecution.status;
                } else {
                    result.status = pipelineExecutionStepState_status.FAILED;
                }
            } else if (rawExecution.runningStep == result.id) {
                this.updateStart(result, StepType.stageDeploy, start, stepStates);
                result.status = pipelineExecutionStepState_status.RUNNING;
            } else if (isPriorStepRunning(rawExecution, stepStates)) {
                result.status = pipelineExecutionStepState_status.NOT_STARTED;
            } else {
                result.status = pipelineExecutionStepState_status.FINISHED;
            }
        }

        stepStates.push(result);
    }

    private createStageDeployStepState(stepStates: PipelineExecutionStepState[], program: any, environmentId: string, rawExecution: any): void {
        const priorSteps = [ StepType.validate, StepType.build, StepType.codeQuality ];
        const start = new Date(rawExecution.createdAt);
        const environment = _.find(program.environments, (env) => {
            return env.name == environmentId;
        });

        const result = new PipelineExecutionStepState({
            id: StepType.stageDeploy,
            stepId: StepType.stageDeploy,
            phaseId: StepPhase.stageDeploy,
            executionId: rawExecution.id,
            pipelineId: rawExecution.pipelineId,
            programId: program.id,
            action: "deploy",
            environmentType: "stage",
            environment: environment.name,
            details: this.generateDeployStepDetails(environment)

        });
        if (priorStepFailed(stepStates)) {
            result.status = pipelineExecutionStepState_status.NOT_STARTED;
        } else {
            if (rawExecution.status == "FINISHED" || rawExecution.status == "FAILED") {
                this.updateStartAndFinish(result, StepType.stageDeploy, start, stepStates);
                if (rawExecution.status == "FINISHED" || rawExecution.failureStep != "stageDeploy") {
                    result.status = rawExecution.status;
                } else {
                    result.status = pipelineExecutionStepState_status.FAILED;
                }
            } else if (rawExecution.runningStep == result.id) {
                this.updateStart(result, StepType.stageDeploy, start, stepStates);
                result.status = pipelineExecutionStepState_status.RUNNING;
            } else if (priorSteps.indexOf(rawExecution.runningStep) >= 0) {
                result.status = pipelineExecutionStepState_status.NOT_STARTED;
            } else {
                result.status = pipelineExecutionStepState_status.FINISHED;
            }
        }

        stepStates.push(result);
    }

    private generateDeployStepDetails(environment: any): any {
        if (environment.urls) {
            return {
                "environmentUrls" : _.map(environment.urls, (value, key) => {
                    return {
                        instanceType: key,
                        instanceUrl: value
                    };
                })
            };
        } else {
            return {};
        }
    }

    private createProductionDeployStepState(stepStates: PipelineExecutionStepState[], program: any, environmentId: string, rawExecution: any): void {
        const priorSteps = [ StepType.validate, StepType.build, StepType.codeQuality, StepType.stageDeploy, StepType.securityTest, StepType.reportPerformanceTest, StepType.approval, StepType.managed, StepType.schedule ];
        const start = new Date(rawExecution.createdAt);
        const result = new PipelineExecutionStepState({
            id: StepType.prodDeploy,
            stepId: StepType.prodDeploy,
            phaseId: StepPhase.prodDeploy,
            executionId: rawExecution.id,
            pipelineId: rawExecution.pipelineId,
            programId: program.id,
            action: "deploy",
            environmentType: "prod",
            environment: environmentId
        });
        if (priorStepFailed(stepStates)) {
            result.status = pipelineExecutionStepState_status.NOT_STARTED;
        } else {
            if (rawExecution.status == "FINISHED" || rawExecution.status == "FAILED") {
                this.updateStartAndFinish(result, StepType.stageDeploy, start, stepStates);
                if (rawExecution.status == "FINISHED" || rawExecution.failureStep != "stageDeploy") {
                    result.status = rawExecution.status;
                } else {
                    result.status = pipelineExecutionStepState_status.FAILED;
                }
            } else if (rawExecution.runningStep == result.id) {
                this.updateStart(result, StepType.stageDeploy, start, stepStates);
                result.status = pipelineExecutionStepState_status.RUNNING;
            } else if (priorSteps.indexOf(rawExecution.runningStep) >= 0) {
                result.status = pipelineExecutionStepState_status.NOT_STARTED;
            } else {
                result.status = pipelineExecutionStepState_status.FINISHED;
            }
        }

        stepStates.push(result);
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/build/step/build/logs")
    public getBuildLogs() {
        return {
            redirect: url.format({
                protocol: this.httpContext.request.protocol,
                hostname: this.httpContext.request.hostname,
                port: this.config.getPort(),
                pathname:  "/files/build_maven_build.log"
              })
        };
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/build/step/codeQuality/logs")
    public getCodeQualityLogs() {
        return {
            redirect: url.format({
                protocol: this.httpContext.request.protocol,
                hostname: this.httpContext.request.hostname,
                port: this.config.getPort(),
                pathname:  "/files/project_issues.csv"
              })
        };
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/stageDeploy/step/stageDeploy/logs")
    public getStageDeployLogs() {
        return {
            redirect: url.format({
                protocol: this.httpContext.request.protocol,
                hostname: this.httpContext.request.hostname,
                port: this.config.getPort(),
                pathname:  "/files/stage_deploy.log"
              })
        };
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/prodDeploy/step/prodDeploy/logs")
    public getProdDeployLogs() {
        return {
            redirect: url.format({
                protocol: this.httpContext.request.protocol,
                hostname: this.httpContext.request.hostname,
                port: this.config.getPort(),
                pathname:  "/files/prod_deploy.log"
              })
        };
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/devDeploy/step/devDeploy/logs")
    public getDevDeployLog() {
        return {
            redirect: url.format({
                protocol: this.httpContext.request.protocol,
                hostname: this.httpContext.request.hostname,
                port: this.config.getPort(),
                pathname:  "/files/dev_deploy.log"
              })
        };
    }

    @httpGet("/program/:programId/pipeline/:pipelineId/execution/:executionId/phase/build/step/buildImage/logs")
    public getBuildImageLog() {
        return {
            redirect: url.format({
                protocol: this.httpContext.request.protocol,
                hostname: this.httpContext.request.hostname,
                port: this.config.getPort(),
                pathname:  "/files/build-image.log"
              })
        };
    }
}