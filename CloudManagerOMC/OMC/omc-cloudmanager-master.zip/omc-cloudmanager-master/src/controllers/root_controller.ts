import {
    controller, httpGet, BaseHttpController
} from "inversify-express-utils";

@controller("/")
class RootController extends BaseHttpController {

    @httpGet("/")
    public get() {
        return this.redirect("/index.html");
    }
}