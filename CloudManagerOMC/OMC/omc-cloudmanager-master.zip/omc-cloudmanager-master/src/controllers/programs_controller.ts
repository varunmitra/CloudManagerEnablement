import { BaseHttpController, controller, httpGet, requestParam, httpPut, requestBody, httpPost } from "inversify-express-utils";
import { inject } from "inversify";
import { TYPES } from "../types";
import { PipelineService } from "../services/pipeline";
import { ProgramService } from "../services/programs";
import { Config } from "../services/config";
import { Ims } from "../services/ims";
import { IProgram, IProgramList, ProgramList, Program, EmbeddedProgram, EmbeddedSolution, ListofQualityMetricThresholds, RepositoryList, Repository, BranchList, RepositoryBranch, SolutionsList, QualityMetricThreshold, ProgramCapabilities } from "../models";
import { RELS } from "../rels";
import { Request, Response } from "express";
import * as url from "url";
import * as _ from "lodash";
import path from "path";
import { UploadedFile } from "express-fileupload";
const fs = require("fs-extra");

@controller("/api")
class Programs extends BaseHttpController {

    @inject(TYPES.Config) private config: Config;
    @inject(TYPES.Ims) private imsService: Ims;
    @inject(TYPES.ProgramService) private programService: ProgramService;
    @inject(TYPES.PipelineService) private pipelineService: PipelineService;


    @httpGet("/programs")
    public getPrograms() {
        const result = new ProgramList();
        const programs = this.programService.getAllRawPrograms();
        result._totalNumberOfItems = programs.length;

        const embeddedPrograms: EmbeddedProgram[] = [];

        let program: any;
        for (program of programs) {
            const embedded = new EmbeddedProgram();
            embedded.id = program.id;
            embedded.name = program.title;
            embedded.enabled = true;
            if (program.tenantId) {
                embedded.tenantId = program.tenantId;
            }
            embedded.capabilities = new ProgramCapabilities(program.capabilities);
            embedded.addLink(RELS.thumbnail, `/api/program/${program.id}/thumbnail`);
            embedded.addSelf(`/api/program/${program.id}`);

            embedded._embedded = {
                solutions: _.map(program.solutions, (solution) => {
                    return this.createSolution(program, solution);
                })
            };

            embeddedPrograms.push(embedded);
        }

        result._embedded = {
            programs: embeddedPrograms
        };

        result.addSelf("/api/programs");
        return result;
    }

    @httpGet("/program/:programId")
    public getProgram(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program) {
            const result = new Program();
            result.id = programId;
            result.imsOrgId = this.imsService.fullOrgId;
            result.product = "AEM";
            result.tenantId = program.tenantId;
            result.name = program.title;
            result.description = program.description;

            result.build_params = {};
            result.deploy_params = {};

            result.scale_settings.setValues(program.scaleSettings);

            result.capabilities = new ProgramCapabilities(program.capabilities);
            result.updateState = program.updateState;

            result.addLink(RELS.currentUser, `/api/program/${programId}/user/me`);
            result.addLink(RELS.environments, `/api/program/${programId}/environments`);
            result.addLink(RELS.pipelines, `/api/program/${programId}/pipelines`);
            result.addLink(RELS.repositories, `/api/program/${programId}/repositories`);
            result.addLink(RELS.runbook, this.config.getRunbookUrl());
            result.addLink(RELS.solutions, `/api/program/${programId}/solutions`);
            result.addLink(RELS.thumbnail, `/api/program/${programId}/thumbnail`);
            result.addSelf(`/api/program/${programId}`);

            return result;
        }

        return undefined;
    }

    @httpPut("/program/:programId")
    public updateProgram(@requestParam("programId") programId: string, @requestBody() body: any) {
        const program = this.programService.getRawProgram(programId);

        program.description = body.description;
        program.scaleSettings = body.scale_settings;

        return 200;
    }

    @httpPost("/program/:programId/branches/:branch")
    public addBranch(@requestParam("programId") programId: string, @requestParam("branch") branch: string) {
        const program = this.programService.getRawProgram(programId);

        program.branches.push(branch);

        return 200;
    }

    @httpGet("/program/:programId/thumbnail")
    public getThumbnail(@requestParam("programId") programId: string, req: Request, res: Response): any {
        const program = this.programService.getRawProgram(programId);
        if (program && program.thumbnail) {
            return {
                redirect: url.format({
                    protocol: req.protocol,
                    hostname: req.hostname,
                    port: this.config.getPort(),
                    pathname: program.thumbnail
                })
            };
        }

        return undefined;
    }

    @httpPut("/program/:programId/thumbnail")
    public async updateThumbnail(@requestParam("programId") programId: string, req: Request, res: Response) {
        const program = this.programService.getRawProgram(programId);
        const file: any = req.files.file;
        const destination = path.join(this.config.getPublicStorageLocation(), "uploads", programId, file.name);

        fs.ensureDirSync(path.join(this.config.getPublicStorageLocation(), "uploads", programId));

        await file.mv(destination);

        program.thumbnail = `/uploads/${programId}/${file.name}`;

        res.sendStatus(200);
    }

    @httpGet("/program/:programId/solutions")
    public getSolutions(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program) {
            const result = new SolutionsList();
            result._totalNumberOfItems = program.solutions.length;
            result.addSelf(`/api/program/${programId}/solutions`);

            result._embedded = {
                solutions: _.map(program.solutions, (solution) => {
                    return this.createSolution(program, solution);
                })
            };


            return result;

        }
        return undefined;
    }

    @httpPost("/program/:programId/solution/:solution/metrics")
    public updateSitesMetrics(@requestParam("programId") programId: string, @requestBody() body: any) {
        const program = this.programService.getRawProgram(programId);
        if (!program.kpis) {
            program.kpis = {};
        }

        _.each(body, (kpi) => {
            switch (kpi.key) {
                case "views_per_minute":
                    program.kpis.avgVisitorsPerMin = parseInt(kpi.thresholdValue, 10);
                    break;
                case "response_time":
                    program.kpis.avgResponseTimeInSec = parseInt(kpi.thresholdValue, 10);
                    break;
                case "processing_time":
                    program.kpis.assetsProcessingTime = parseInt(kpi.thresholdValue, 10);
                    break;
                case "uploads_per_minute":
                    program.kpis.assetsUploadPerMinute = parseInt(kpi.thresholdValue, 10);
                    break;
            }
        });

        return 200;
    }

    @httpGet("/program/:programId/repositories")
    public getRepositories(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program) {
            const result = new RepositoryList();
            result._totalNumberOfItems = 1;
            result.addSelf(`/api/program/${programId}/repositories`);

            const repo = new Repository();
            repo.description = program.title;
            repo.id = "1";
            repo.repo = program.id;
            repo.programId = programId;
            repo.url = "ssh://something/something";
            result._embedded = {
                repositories : [
                    repo
                ]
            };
            repo.addLink(RELS.branches, `/api/program/${programId}/repository/${program.id}/branches`);
            repo.addLink(RELS.program, `/api/program/${programId}`);
            repo.addSelf(`/api/program/${programId}/repository/${program.id}`);


            return result;
        }
        return undefined;
    }

    @httpGet("/program/:programId/repository/:repositoryId/branches")
    public getBranches(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);
        if (program) {
            const result = new BranchList();
            result._totalNumberOfItems = program.branches.length;

            const branches: RepositoryBranch[] = [];

            result._embedded = {
                branches: _.map(program.branches, (branch) => {
                    const obj = new RepositoryBranch();
                    obj.repositoryId = 1;
                    obj.name = branch;
                    obj.addLink(RELS.program, `/api/program/${programId}`);
                    obj.addLink(RELS.repository, `/api/program/${programId}/repository/1`);
                    return obj;
                })
            };

            result.addSelf(`/api/program/${programId}/repository/${programId}/branches`);

            return result;
        }
        return undefined;
    }

    @httpPut("/program/:programId/repository/:repositoryId/code-generator")
    public generateProject(@requestParam("programId") programId: string, @requestBody() body: any) {
        const program = this.programService.getRawProgram(programId);
        if (program) {
            this.pipelineService.startCodeGeneratorExecution(programId, body);
            return {};
        }
        return undefined;
    }


    private createSolution(program: any, solutionName: string): EmbeddedSolution {
        const result = new EmbeddedSolution();
        result.id = solutionName;
        result.name = solutionName;

        const metrics: QualityMetricThreshold[] = [];

        switch (solutionName) {
            case "aemsites": {
                if (program.kpis && program.kpis.avgVisitorsPerMin) {
                    metrics.push(new QualityMetricThreshold({
                        id: 1,
                        comparator: "lt",
                        key: "views_per_minute",
                        severity: "important",
                        thresholdValue: program.kpis.avgVisitorsPerMin.toString(),
                        unitType: "double"
                    }));
                }
                if (program.kpis && program.kpis.avgResponseTimeInSec) {
                    metrics.push(new QualityMetricThreshold({
                        id: 2,
                        comparator: "gt",
                        key: "response_time",
                        severity: "important",
                        thresholdValue: program.kpis.avgResponseTimeInSec.toString(),
                        unitType: "double"
                    }));
                }
                break;
            }
            case "aemassets": {
                if (program.kpis && program.kpis.assetsProcessingTime) {
                    metrics.push(new QualityMetricThreshold({
                        id: 3,
                        comparator: "lt",
                        key: "processing_time",
                        severity: "important",
                        thresholdValue: program.kpis.assetsProcessingTime.toString(),
                        unitType: "double"
                    }));
                }
                if (program.kpis && program.kpis.assetsUploadPerMinute) {
                    metrics.push(new QualityMetricThreshold({
                        id: 4,
                        comparator: "gte",
                        key: "uploads_per_minute",
                        severity: "important",
                        thresholdValue: program.kpis.assetsUploadPerMinute.toString(),
                        unitType: "double"
                    }));
                }
                break;
            }
        }

        result.metrics = new ListofQualityMetricThresholds();
        result.metrics._totalNumberOfItems = metrics.length;
        result.metrics._embedded = {
            qualityMetricThresholds: metrics
        };
        result.addLink(RELS.solutionMetrics, `/api/program/${program.id}/solution/${solutionName}/metrics`);
        result.addLink(RELS.endpoint, this.config.getAuthorUrl());
        result.addSelf(`/api/program/${program.id}/solution/${solutionName}`);

        return result;
    }

}