import { controller, BaseHttpController, requestParam, httpGet, httpPut, requestBody, httpPost, httpDelete } from "inversify-express-utils";
import { inject } from "inversify";
import { TYPES } from "../types";
import { ProgramService } from "../services/programs";
import { PipelineList, Pipeline, pipeline_type, pipeline_status, pipelinePhase_type, PipelinePhase, PipelineStep, AssetCollection, EmbeddedAsset, IPipeline, pipeline_trigger } from "../models";
import { RELS } from "../rels";
import * as _ from "lodash";
import { v4 } from "uuid";
import path from "path";
import { Request, Response } from "express";
import { Config, CiCdPipelineType } from "../services/config";
import { isCloud } from "../helpers/program-helper";
const fs = require("fs-extra");

@controller("/api")
class PipelineController extends BaseHttpController {

    @inject(TYPES.ProgramService) private programService: ProgramService;
    @inject(TYPES.Config) private config: Config;

    @httpGet("/program/:programId/pipelines")
    public getPipelines(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);

        const result = new PipelineList();
        result.addSelf(`/api/program/${programId}/pipelines`);
        const pipelines: IPipeline[] = [];
        if (program.pipeline) {
            pipelines.push(this.generateProductionPipeline(program, program.pipeline, this.config.getMainPipelineName()));
        }
        if (program.validationPipeline && program.updateState.validationPipeline && program.updateState.validationPipeline.id) {
            pipelines.push(this.generateProductionPipeline(program, program.validationPipeline, program.updateState.validationPipeline.id));
        }

        if (program.nonProductionPipelines) {
            _.each(program.nonProductionPipelines, p => {
                const pipeline = new Pipeline();
                pipeline.createdAt = new Date("1970-01-01");
                pipeline.id = p.name;
                pipeline.importantMetricsFailureBehavior = p.importantMetricsFailureBehavior;
                pipeline.name = p.name;
                pipeline.phases = [
                    new PipelinePhase({
                        name: "validate",
                        type: pipelinePhase_type.VALIDATE
                    }),
                    new PipelinePhase({
                        name: "build",
                        type: pipelinePhase_type.BUILD,
                        repositoryId: "1",
                        branch: p.branch
                    })
                ];
                if (p.type !== CiCdPipelineType.codeQualityOnly) {
                    pipeline.phases.push(new PipelinePhase({
                        environmentId: _.find(program.environments, (env) => {
                            return env.name == p.environmentId;
                        }).name,
                        environmentType: "dev",
                        name: "deploy",
                        type: pipelinePhase_type.DEPLOY,
                        steps: [
                            {
                                name: "deploy",
                                options: {}
                            }
                        ]
                    }));
                }
                pipeline.programId = programId;
                if (program.activeExecutionId && program.activeExecutionId[pipeline.id]) {
                    pipeline.status = pipeline_status.BUSY;
                } else {
                    pipeline.status = pipeline_status.IDLE;
                }
                pipeline.trigger = p.trigger.toUpperCase();
                pipeline.type = pipeline_type.CI_CD;
                pipeline.updatedAt = new Date("1970-01-01");
                pipeline.addLink(RELS.advance, `/api/program/${programId}/pipeline/${pipeline.id}/execution/advance`);
                pipeline.addLink(RELS.execution, `/api/program/${programId}/pipeline/${pipeline.id}/execution`);
                pipeline.addLink(RELS.executions, `/api/program/${programId}/pipeline/${pipeline.id}/executions`);
                pipeline.addLink(RELS.program, `/api/program/${programId}`);
                pipeline.addSelf(`/api/program/${programId}/pipeline/${pipeline.id}`);
                pipelines.push(pipeline);
            });
        }

        result._totalNumberOfItems = pipelines.length;
        result._embedded = {
            pipelines: pipelines
        };


        return result;
    }

    private generateProductionPipeline(rawProgram: any, rawPipeline: any, name: string): IPipeline {
        const pipeline = new Pipeline();
        pipeline.createdAt = new Date("1970-01-01");
        pipeline.id = name;
        pipeline.importantMetricsFailureBehavior = rawPipeline.importantMetricsFailureBehavior;
        if (rawProgram.executions) {
            const lastFinish = _.find(rawProgram.executions, (execution) => {
                return execution.status == "FINISHED";
            });
            if (lastFinish) {
                pipeline.lastFinishedAt = lastFinish.finishedAt;
            }
            const lastStart = _.find(rawProgram.executions, (execution) => {
                return true;
            });
            if (lastStart) {
                pipeline.lastStartedAt = lastStart.createdAt;
            }
        }
        pipeline.name = name;

        pipeline.phases = [
            new PipelinePhase({
                name: "validate",
                type: pipelinePhase_type.VALIDATE
            }),
            new PipelinePhase({
                name: "build",
                type: pipelinePhase_type.BUILD,
                repositoryId: "1",
                branch: rawPipeline.branch
            }),
            new PipelinePhase({
                environmentId: rawPipeline.stageEnvironmentId,
                assetCollectionId: rawPipeline.assetCollectionId ? rawPipeline.assetCollectionId : undefined,
                environmentType: "stage",
                name: "deploy",
                type: pipelinePhase_type.DEPLOY,
                steps: [
                    {
                        name: "deploy",
                        options: {
                            dispatcherCacheFlushPaths: _.map(_.filter(rawPipeline.stageDispatcher, (e) => { return e.action == "flush"; }), (e) => { return e.path; }),
                            dispatcherCacheInvalidationPaths: _.map(_.filter(rawPipeline.stageDispatcher, (e) => { return e.action == "invalidate"; }), (e) => { return e.path; })
                        }
                    },
                    {
                        name: "loadTest",
                        options: {
                            popularPagesWeight: rawPipeline.popularPagesWeight,
                            otherPagesWeight: rawPipeline.otherPagesWeight,
                            newPagesWeight: rawPipeline.newPagesWeight

                        }
                    },
                    {
                        name: "assetsTest",
                        options: {
                            imageAssetsWeight: rawPipeline.imageAssetsWeight,
                            pdfAssetsWeight: rawPipeline.pdfAssetsWeight

                        }
                    }
                ]
            }),
            new PipelinePhase({
                environmentId: rawPipeline.prodEnvironmentId,
                environmentType: "prod",
                name: "deploy",
                type: pipelinePhase_type.DEPLOY,
                steps: [
                    {
                        name: "deploy",
                        options: {
                            dispatcherCacheFlushPaths: _.map(_.filter(rawPipeline.productionDispatcher, (e) => { return e.action == "flush"; }), (e) => { return e.path; }),
                            dispatcherCacheInvalidationPaths: _.map(_.filter(rawPipeline.productionDispatcher, (e) => { return e.action == "invalidate"; }), (e) => { return e.path; })
                        }
                    }
                ]
            })
        ];
        if (!isCloud(rawProgram) && rawPipeline.cseoversight) {
            pipeline.phases[3].steps.unshift(new PipelineStep({
                name: "managed",
                options: {
                    cse: (("anyCse" == rawPipeline.cseType) ? "ANY_CSE" : "MY_CSE")
                }
            }));
        }
        if (rawPipeline.scheduled) {
            pipeline.phases[3].steps.unshift(new PipelineStep({
                name: "schedule"
            }));
        }
        if (rawPipeline.goliveapproval) {
            pipeline.phases[3].steps.unshift(new PipelineStep({
                name: "approval"
            }));
        }

        pipeline.programId = rawProgram.id;
        if (rawProgram.activeExecutionId && rawProgram.activeExecutionId[pipeline.id]) {
            pipeline.status = pipeline_status.BUSY;
        } else {
            pipeline.status = pipeline_status.IDLE;
        }
        if (rawPipeline.trigger) {
            pipeline.trigger = rawPipeline.trigger.toUpperCase();
        } else {
            pipeline.trigger = pipeline_trigger.MANUAL;
        }
        pipeline.type = pipeline_type.CI_CD;
        pipeline.updatedAt = new Date("1970-01-01");

        pipeline.addLink(RELS.advance, `/api/program/${rawProgram.id}/pipeline/${pipeline.id}/execution/advance`);
        pipeline.addLink(RELS.execution, `/api/program/${rawProgram.id}/pipeline/${pipeline.id}/execution`);
        pipeline.addLink(RELS.executions, `/api/program/${rawProgram.id}/pipeline/${pipeline.id}/executions`);
        pipeline.addLink(RELS.program, `/api/program/${rawProgram.id}`);
        pipeline.addSelf(`/api/program/${rawProgram.id}/pipeline/${pipeline.id}`);

        return pipeline;
    }

    @httpPost("/program/:programId/pipelines")
    public createPipeline(@requestParam("programId") programId: string, @requestBody() body: any) {
        return this.updatePipeline(programId, undefined, body);
    }

    private cleanName(name: string): string {
        return name.replace(/\#/g, "");
    }

    @httpPut("/program/:programId/pipeline/:pipelineId")
    public updatePipeline(@requestParam("programId") programId: string, @requestParam("pipelineId") pipelineId: string, @requestBody() body: any) {
        const program = this.programService.getRawProgram(programId);
        if (!program.pipeline) {
            program.pipeline = {};
        }
        if (!program.nonProductionPipelines) {
            program.nonProductionPipelines = [];
        }
        let pipelineToUpdate: any;
        let isNonProd: boolean = false;
        if (pipelineId) {
            if (pipelineId === this.config.getMainPipelineName()) {
                pipelineToUpdate = program.pipeline;
            } else {
                pipelineToUpdate = _.find(program.nonProductionPipelines, p => p.name === pipelineId);
                isNonProd = true;
            }
        } else {
            if (body.phases.length === 1) {
                pipelineToUpdate = {
                    name: this.cleanName(body.name),
                    type: CiCdPipelineType.codeQualityOnly
                };
                isNonProd = true;
                program.nonProductionPipelines.push(pipelineToUpdate);
            } else if (body.phases.length == 2) {
                pipelineToUpdate = {
                    name: this.cleanName(body.name),
                    type: CiCdPipelineType.nonProductionDeploy
                };
                isNonProd = true;
                program.nonProductionPipelines.push(pipelineToUpdate);
            } else {
                pipelineToUpdate = program.pipeline;
            }
        }

        if (isNonProd) {
            pipelineToUpdate.name =  this.cleanName(body.name);
        }

        pipelineToUpdate.importantMetricsFailureBehavior = body.importantMetricsFailureBehavior;
        pipelineToUpdate.trigger = body.trigger;

        const buildPhase = _.find(body.phases, (phase) => {
            return phase.type == "BUILD";
        });
        if (buildPhase) {
            pipelineToUpdate.branch = buildPhase.branch;
        }

        const devDeploymentPhase = _.find(body.phases, (phase) => {
            return phase.environmentType == "dev";
        });
        if (devDeploymentPhase) {
            pipelineToUpdate.environmentId = devDeploymentPhase.environmentId;
        }

        const stageDeploymentPhase = _.find(body.phases, (phase) => {
            return phase.environmentType == "stage";
        });
        if (stageDeploymentPhase) {

            const stageDeployStep = _.find(stageDeploymentPhase.steps, (step) => {
                return step.name == "deploy";
            });
            pipelineToUpdate.stageEnvironmentId = stageDeploymentPhase.environmentId;
            pipelineToUpdate.assetCollectionId = stageDeploymentPhase.assetCollectionId;
            pipelineToUpdate.stageDispatcher = [];
            if (stageDeployStep.options && stageDeployStep.options.dispatcherCacheFlushPaths) {
                _.forEach(stageDeployStep.options.dispatcherCacheFlushPaths, (path) => {
                    pipelineToUpdate.stageDispatcher.push({
                        "path" : path,
                        "action" : "flush"
                    });
                });
            }
            if (stageDeployStep.options && stageDeployStep.options.dispatcherCacheInvalidationPaths) {
                _.forEach(stageDeployStep.options.dispatcherCacheInvalidationPaths, (path) => {
                    pipelineToUpdate.stageDispatcher.push({
                        "path" : path,
                        "action" : "invalidate"
                    });
                });
            }

            const loadTest = _.find(stageDeploymentPhase.steps, (step) => {
                return step.name == "loadTest";
            });
            if (loadTest) {
                _.assign(pipelineToUpdate, loadTest.options);
            }
            const assetsTest = _.find(stageDeploymentPhase.steps, (step) => {
                return step.name == "assetsTest";
            });
            if (assetsTest) {
                _.assign(pipelineToUpdate, assetsTest.options);
            }
        }
        const prodDeploymentPhase = _.find(body.phases, (phase) => {
            return phase.environmentType == "prod";
        });
        if (prodDeploymentPhase) {
            const prodDeployStep = _.find(prodDeploymentPhase.steps, (step) => {
                return step.name == "deploy";
            });
            pipelineToUpdate.prodEnvironmentId = prodDeploymentPhase.environmentId;
            pipelineToUpdate.productionDispatcher = [];
            if (prodDeployStep.options && prodDeployStep.options.dispatcherCacheFlushPaths) {
                _.forEach(prodDeployStep.options.dispatcherCacheFlushPaths, (path) => {
                    pipelineToUpdate.productionDispatcher.push({
                        "path" : path,
                        "action" : "flush"
                    });
                });
            }
            if (prodDeployStep.options && prodDeployStep.options.dispatcherCacheInvalidationPaths) {
                _.forEach(prodDeployStep.options.dispatcherCacheInvalidationPaths, (path) => {
                    pipelineToUpdate.productionDispatcher.push({
                        "path" : path,
                        "action" : "invalidate"
                    });
                });
            }

            if (_.find(prodDeploymentPhase.steps, (step) => {
                return step.name == "approval";
            })) {
                pipelineToUpdate.goliveapproval = true;
            } else {
                pipelineToUpdate.goliveapproval = false;
            }
            const managedStep = _.find(prodDeploymentPhase.steps, (step) => {
                return step.name == "managed";
            });
            if (managedStep) {
                pipelineToUpdate.cseoversight = true;
                if (managedStep.options.cse == "MY_CSE") {
                    pipelineToUpdate.cseType = "myCse";
                } else {
                    pipelineToUpdate.cseType = "anyCse";
                }
            } else {
                pipelineToUpdate.cseoversight = false;
            }
            if (_.find(prodDeploymentPhase.steps, (step) => {
                return step.name == "schedule";
            })) {
                pipelineToUpdate.scheduled = true;
            } else {
                pipelineToUpdate.scheduled = false;
            }
        }

        return 200;
    }

    @httpPost("/program/:programId/assetCollections")
    public createAssetCollection(@requestParam("programId") programId: string) {
        const program = this.programService.getRawProgram(programId);

        const collectionId = v4();

        return this.getAssetCollection(programId, collectionId);

    }

    @httpGet("/program/:programId/assetCollection/:assetCollectionId")
    public getAssetCollection(@requestParam("programId") programId: string, @requestParam("assetCollectionId") assetCollectionId: string) {
        const collection = this.getRawAssetCollection(programId, assetCollectionId);

        const result = new AssetCollection();
        result.programId = programId;
        result.id = assetCollectionId;
        result.addLink(RELS.program, `/api/program/${programId}`);
        result.addSelf(`/api/program/${programId}/assetCollection/${assetCollectionId}`);

        result._embedded = {
            assets: _.map(collection, (entry) => {
                const stats = fs.statSync(path.join(this.config.getStorageLocation(), entry.path));

                const ea = new EmbeddedAsset({
                    id: entry.id,
                    programId: programId,
                    assetCollectionId: assetCollectionId,
                    name: entry.name,
                    contentType: entry.contentType,
                    size: `${stats.size}`

                });

                ea.addLink(RELS.assetCollection, `/api/program/${programId}/assetCollection/${assetCollectionId}`);
                ea.addSelf(`/api/program/${programId}/assetCollection/${assetCollectionId}/asset/${entry.id}`);

                return ea;
            })
        };

        return result;
    }

    @httpPost("/program/:programId/assetCollection/:assetCollectionId")
    public cloneAssetCollection(@requestParam("programId") programId: string, @requestParam("assetCollectionId") assetCollectionId: string) {
        const collectionId = this.cloneRawAssetCollection(programId, assetCollectionId);

        return this.getAssetCollection(programId, collectionId);
    }

    @httpPost("/program/:programId/assetCollection/:assetCollectionId/assets")
    public async uploadAsset(@requestParam("programId") programId: string, @requestParam("assetCollectionId") assetCollectionId: string,
                             req: Request, res: Response) {
        const collection = this.getRawAssetCollection(programId, assetCollectionId);

        const file: any = req.files.file;
        const destination = path.join(this.config.getStorageLocation(), "uploads", programId, file.name);

        fs.ensureDirSync(path.join(this.config.getStorageLocation(), "uploads", programId));

        await file.mv(destination);

        collection.push({
            id: v4(),
            path: `/uploads/${programId}/${file.name}`,
            contentType: file.mimetype,
            name: file.name
        });

        return this.getAssetCollection(programId, assetCollectionId);
    }

    @httpDelete("/program/:programId/assetCollection/:assetCollectionId/asset/:assetId")
    public async deleteAsset(@requestParam("programId") programId: string, @requestParam("assetCollectionId") assetCollectionId: string,
                             @requestParam("assetId") assetId: string, req: Request, res: Response) {
        const collection = this.getRawAssetCollection(programId, assetCollectionId);

        _.remove(collection, asset => asset.id === assetId);

        return this.getAssetCollection(programId, assetCollectionId);
    }

    private cloneRawAssetCollection(programId: string, sourceAssetCollectionId: string): string {
        const program = this.programService.getRawProgram(programId);
        if (!program.assetCollections) {
            program.assetCollections = {};
        }
        let collection = program.assetCollections[sourceAssetCollectionId];
        if (!collection) {
            collection = [];
        }

        const newCollectionId = v4();
        program.assetCollections[newCollectionId] = _.cloneDeep(collection);
        return newCollectionId;
    }

    private getRawAssetCollection(programId: string, assetCollectionId: string): any[] {
        const program = this.programService.getRawProgram(programId);
        if (!program.assetCollections) {
            program.assetCollections = {};
        }
        let collection = program.assetCollections[assetCollectionId];
        if (!collection) {
            collection = [];
            program.assetCollections[assetCollectionId] = collection;
        }
        return collection;
    }
}