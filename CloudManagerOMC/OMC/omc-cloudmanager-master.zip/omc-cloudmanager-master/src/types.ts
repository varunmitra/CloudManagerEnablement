export const TYPES = {
    Config: Symbol.for("Config"),
    Ims: Symbol.for("Ims"),
    ProgramService: Symbol.for("ProgramService"),
    UserService: Symbol.for("UserService"),
    Pulse: Symbol.for("Pulse"),
    PipelineService: Symbol.for("PipelineService")
};