import { container, app } from "./app";
import { SkylineHelper } from "./helpers/skyline-init";
import { TYPES } from "./types";
import { ProgramService } from "./services/programs";
import { Pulse } from "./services/pulse";
import { Config } from "./services/config";

const skylineHelper = new SkylineHelper();

const pulse: Pulse = container.get(TYPES.Pulse);
const programService: ProgramService = container.get(TYPES.ProgramService);
const config: Config = container.get(TYPES.Config);

programService.addInitHook(() => {
  skylineHelper.initPrograms(programService);
});
programService.reset();

app.listen(app.get("port"), () => {
  console.log(
    "  OMC Cloud Manager listening on port %d",
    app.get("port")
  );
  console.log("  Press CTRL-C to stop\n");
});
