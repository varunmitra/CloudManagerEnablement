import * as shell from "shelljs";

shell.rm("-rf", "src/public/content/cv-ui");
shell.mkdir("-p", "src/public/content/cv-ui");
shell.cp("-R", "../self-service-cvui/build/*", "src/public/content/cv-ui/");