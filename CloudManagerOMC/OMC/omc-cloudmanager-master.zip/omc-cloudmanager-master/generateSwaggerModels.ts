import path from "path";
import * as shell from "shelljs";
import { generateTSFiles } from "swagger-ts-generator";
import * as _ from "lodash";
import Handlebars from "handlebars";

class Rewriter {

  mappings = {};

  public refRewriter() {
    return (value, key, object, stack) => {
      const mappings = {};
      if ("$ref" === key) {
        const trimmedValue = value.substring(value.lastIndexOf("/") + 1);
        const cleanedValue = trimmedValue.replace(/\W/g, "");
        this.mappings[trimmedValue] = cleanedValue;
        return cleanedValue;
      }
      return undefined;
    };
  }

  public definitionRewriter() {
    return (value, key, object, stack) => {
      if ("definitions" === key) {
        const result = {};
        _.forIn(value, (def, key) => {
          const newKey = this.mappings[key];
          result[newKey] = _.cloneDeep(def);
        });
        return result;
      }
      return undefined;
    };
  }

  public enumRewriter() {
    return (value, key, object, stack) => {
      if (_.isObject(value) && _.has(value, "properties")) {
        _.each(value.properties, (innerValue, innerKey) => {
          if (_.has(innerValue, "enum")) {
            const cleanedDescription = key.replace(/\s/, "");
            innerValue.description = `type ${cleanedDescription}_${innerKey}`;
          }
        });
      }
      return undefined;
    };
  }

  public addingUpdateStateRewiter() {
    return (value, key, object, stack) => {
      if (key === "Program") {
        value.properties["updateState"] = {
          type: "object"
        };
      }
    };
  }

  public fixingEnvironmentInstanceRewriter() {
    return (value, key, object, stack) => {
      if (key === "EnvironmentInstance") {
        value.properties["hostName"] = {
          type: "string"
        };
        value.properties["status"] = {
          type: "string"
        };
        value.properties["_totalNumberOfItems"] = {
          "type" : "integer",
          "format" : "int32"
        };
        value.properties["_embedded"] = {
          "type" : "object",
          "properties" : {
            "metrics" : {
              "type" : "array",
              "items" : {
                "type" : "object"
              }
            }
          }
        };
      }
    };
  }

  public fixInstanceMonitoringListRewriter() {
    return (value, key, object, stack) => {
      if (key === "Instance Monitoring List") {
        const current = value.properties._embedded.properties.instances.items["$ref"];
        value.properties._embedded.properties.instances.items["$ref"] = current.replace("Instance Monitoring List", "Monitoring Metric Threshold");
      }
    };
  }

}

const refRewriter = new Rewriter();
let swaggerFile = require("./config/swagger.json");
// swaggerFile = _.cloneDeepWith(swaggerFile, refRewriter.fixInstanceMonitoringListRewriter());
swaggerFile = _.cloneDeepWith(swaggerFile, refRewriter.refRewriter());
swaggerFile = _.cloneDeepWith(swaggerFile, refRewriter.definitionRewriter());
swaggerFile = _.cloneDeepWith(swaggerFile, refRewriter.enumRewriter());
swaggerFile = _.cloneDeepWith(swaggerFile, refRewriter.addingUpdateStateRewiter());
// swaggerFile = _.cloneDeepWith(swaggerFile, refRewriter.fixingEnvironmentInstanceRewriter());

shell.rm("./src/models/*");

Handlebars.registerHelper("unlessEquals", function(arg1, arg2, options) {
  return (arg1 != arg2) ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper("ifHasLinks", function(properties, options) {
  if (_.find(properties, (property) => {
    return property.name == "_links";
  })) {
    return options.fn(this);
  } else {
    return options.inverse(this);
  }
});

Handlebars.registerHelper("ifNotLink", function(options) {
  return (this.name != "_links") ? options.fn(this) : options.inverse(this);
});

generateTSFiles(
  swaggerFile,
  {
    modelFolder: "./src/models",
    enumTSFile: "./src/models/enums.ts",
    generateValidatorFile: false,
    enumRef: "./enums",
    templates: {
        baseModel: "./templates/generate-base-model-ts.hbs",
        models: "./templates/generate-model-ts.hbs",
        barrel: "./templates/generate-barrel-ts.hbs",
        enum: "./templates/generate-enums-ts.hbs",
        subTypeFactory: "./templates/generate-sub-type-factory-ts.hbs"
    }
    // + optionally more configuration
  }
);