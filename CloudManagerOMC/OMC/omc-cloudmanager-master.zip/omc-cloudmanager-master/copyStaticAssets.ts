import * as shell from "shelljs";

shell.rm("-rf", "dist");
shell.mkdir("-p", "dist/public");
shell.cp("-R", "src/public/content/cv-ui/*", "dist/public/");
shell.cp("-R", "src/public/images", "dist/public/");
shell.cp("-R", "src/public/files", "dist/public/");
shell.cp("-R", "src/public/performanceData", "dist/public/");