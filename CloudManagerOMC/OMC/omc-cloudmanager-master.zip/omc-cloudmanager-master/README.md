# Offline Marketing Cloud - Cloud Manager Edition

## Usage

### Prerequisites

* [Node](https://nodejs.org/en/) 10.x LTS version
* NPM (usually installed with Node)

### Build and Run

Download the ZIP or clone this repo. Unzip the file (if you downloaded the ZIP) and in a terminal window, go into that directory and run:

    $ npm install
    $ npm run build
    $ npm run serve
    $ open http://localhost:3000

### Alternative Modes

There are alternative modes which can be run by using a different command instead of `npm run serve`:

* "VM Update" Mode -- this sets the programs in a state where We.Retail Global is ready to be upgraded to AEM 6.5 via the Blue/Green VM update process. To run use `npm run update-serve`
* "Skyline" Mode (Beta) -- this sets all programs to be Skyline (AEM Cloud). To run use `npm run skyline-serve`

> "Skyline Update" Mode is coming soon. Promise.

### Executables

You can also download runnable executables for OSX and Windows from https://omc-cloudmanager-builds.ci.corp.adobe.com/job/omc-cloudmanager-master/

## Development

### Updating

This project _embeds_ the built React application from https://git.corp.adobe.com/experience-platform/self-service-cvui. When the UI application changes, the React app needs to be rebuilt and updated here. To do this, make sure that https://git.corp.adobe.com/experience-platform/self-service-cvui is cloned in a parallel directory (i.e. if this project is in `/Users/you/projects/omc-cloudmanager`, the UI needs to be in `/Users/you/projects/self-service-cvui`).

In the `self-service-cvui` directory, create a file named `.env.local` with the content `REACT_APP_OFFLINE=true`. Then, in this directory, run:

    $ yarn build

Then go back to the `omc-cloudmanager` directory and run:

    $ npm run copy-react-build


### Running UI for Debugging Purposes

During development, it is sometimes useful to run the UI development server. To do this, you'll need to clone https://git.corp.adobe.com/experience-platform/self-service-cvui. In the `self-service-cvui` directory, create a file named `.env.local` with the content `REACT_APP_OFFLINE=true`. Then, in that directory, run:

    $ PORT=4000 yarn start

And then open http://localhost:4000.

To avoid unnecessary errors, you should start the OMC server first.
